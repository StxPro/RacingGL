#include <windows.h>
#include <math.h>
#include <GL/gl.h>
//#include <GL/glut.h>
#include <iostream>
#include <ctime> 
#include <array>
#include <vector>
#include "glut.h"
#include <gl/GLU.h>

static bool white = true;
static bool red = false;
static bool green = false;
static bool blue = false;
static bool fog = true;

double fogDensity = 0.01;

double xx = 0.0;
double yy = 0.0;
double zz = 5.0;

struct arr
{
	double array[3];
};

struct arr1
{
	double array[1];
};

typedef	struct node {
	void(*transform)();
	void(*draw)();
	struct node *child;
	struct node *sibling;
}node;

float rota;

float iint = 1.0;

void traverse(node *root) {
	glPushMatrix();

	root->transform();
	root->draw();

	if (root->child != NULL)
	{
		traverse(root->child);
	}

	glPopMatrix();

	if (root->sibling != NULL)
		traverse(root->sibling);
}

void drawCylinder(GLdouble baseRadius,
	GLdouble topRadius,
	GLdouble height,
	GLint slices,
	GLint stacks)
{
	GLUquadricObj *qobj;
	qobj = gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluCylinder(qobj, baseRadius, topRadius, height,
		slices, stacks);
}


void CreateShape() {

}

void init(void)
{

	

	/*root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = NULL;
	root.sibling = NULL;*/

	CreateShape();
}

void pintar(arr spec, arr1 shiny, arr amb, arr dif, double x, double y, double z) {
	//glPushMatrix();
	GLfloat mat_spec[] = { spec.array[0], spec.array[1], spec.array[2] };
	GLfloat mat_shiny[] = { shiny.array[0] };
	GLfloat mat_amb[] = { amb.array[0], amb.array[1], amb.array[2] };
	GLfloat mat_dif[] = { dif.array[0], dif.array[1], dif.array[2] };
	// Set material properties, as defined above 
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_amb);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_dif);
	glTranslatef(x, y, z);
	glRotatef(rota, 0.0, 1.0, 0.0);
	//glutSolidSphere(1.0, 20, 20);
	//glPopMatrix();
}

void display(void) {
	// Clear the buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Get model - from library 
	//glutSolidTeapot(0.80);
	// Define material properties 

	// Set light properties ... 
	GLfloat white_light[] = { iint, iint, iint, 1.0 };

	// and create two lights at two positions 
	GLfloat light_pos0[] = { 0.0, 5.0, zz, 1.0 };
	GLfloat light_posl[] = { 0.0, 5.0, zz, 1.0 };




	// Set clear (background) color 
	glClearColor(0.2, 0.2, 0.2, 0.0);

	// Set shading model to use 
	glShadeModel(GL_SMOOTH);

	// Finish setting up the two lights (position, 
	// and component values (specular and diffuse)) 
	// Luz ambiente difuso especular posicion
	// Material 
	//w
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	GLfloat cutoff[] = { 5.0 };
	GLfloat expo[] = { 2.0 };
	GLfloat dir[] = { xx, yy, -1.0 };

	//q
	glLightfv(GL_LIGHT1, GL_POSITION, light_posl);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);
	glLightfv(GL_LIGHT1, GL_SPOT_CUTOFF, cutoff);
	glLightfv(GL_LIGHT1, GL_SPOT_EXPONENT, expo);
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir);


	// Enable lighting 
	glEnable(GL_LIGHTING);
	// Act�vate (enable) individual lights 
	glEnable(GL_LIGHT0);
	//glEnable(GL_LIGHT1);

	// Enable depth testing (for hidden surface removal) 
	glEnable(GL_DEPTH_TEST);

	if (white) {
		glEnable(GL_LIGHT0);
		glDisable(GL_LIGHT1);
	}
	else {
		glDisable(GL_LIGHT0);
		glEnable(GL_LIGHT1);
	}

	if(fog)
		glEnable(GL_FOG);
	else
		glDisable(GL_FOG);
	GLfloat fogColor[] = { 0.5f, 0.5f, 0.5f, 1.0f };
	glFogi(GL_FOG_MODE, GL_EXP);
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogf(GL_FOG_DENSITY, fogDensity);
	glFogf(GL_FOG_START, 1.0f);
	glFogf(GL_FOG_END, 1.0f);

	glPushMatrix();

	glPushMatrix();
	//glTranslatef(-6.5, 9.0, 0.0);
	//glRotatef(rota, 0.0, 1.0, 0.0);
	glPushMatrix();
	pintar({ 0.393548, 0.271906, 0.166721 }, { 25.6 }, { 0.2125, 0.1275, 0.054 }, { 0.714, 0.4284, 0.18144 }, -6.5, 9.0, 0.0);
	//{ 0.992157, 0.941176, 0.807843 }, { 27.8974 }, { 0.329412, 0.223529, 0.027451 }, { 0.780392, 0.568627, 0.113725 }
	//{ 0.50, 0.50, 0.50 }, { 32.0 }, { 0.0, 0.0, 0.0 }, { 0.01, 0.01, 0.01 }
	//glTranslatef(-6.5, 9.0, 0.0);

	glRotatef(45, 0.0, 0.0, 1.0);
	glRotatef(rota, 1.0, 0.0, 0.0);
	glScalef(2.0, 2.0, 2.0);
	glRotatef(rota, 0.0, 1.0, 0.0);
	glutSolidCube(1.0);
	glPopMatrix();
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.992157, 0.941176, 0.807843 }, { 27.8974 }, { 0.329412, 0.223529, 0.027451 }, { 0.780392, 0.568627, 0.113725 }, 0.0, 5.0, 0.0);
	glutSolidSphere(2.2, 20, 20);
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.50, 0.50, 0.50 }, { 32.0 }, { 0.0, 0.0, 0.0 }, { 0.01, 0.01, 0.01 }, -6.5, 0.0, 0.0);
	glutSolidSphere(1.7, 20, 20);
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.774597, 0.774597, 0.774597 }, { 76.8 }, { 0.25, 0.25, 0.25 }, { 0.4, 0.4, 0.4 }, -6.5, 5.0, 0.0);
	glBegin(GL_QUADS);
	//U
	glNormal3f(0.0f, 1.0f, 0.0f);
	glVertex3f(-1.5f, 1.5f, 1.5f);
	glVertex3f(-1.5f, 1.5f, -1.5f);
	glVertex3f(1.5f, 1.5f, -1.5f);
	glVertex3f(1.5f, 1.5f, 1.5f);
	//F
	glNormal3f(0.0f, 0.0f, 1.0f);
	glVertex3f(-1.5f, -1.5f, 1.5f);
	glVertex3f(1.5f, -1.5f, 1.5f);
	glVertex3f(1.5f, 1.5f, 1.5f);
	glVertex3f(-1.5f, 1.5f, 1.5f);
	//R
	glNormal3f(1.0f, 0.0f, 0.0f);
	glVertex3f(1.5f, -1.5f, -1.5f);
	glVertex3f(1.5f, 1.5f, -1.5f);
	glVertex3f(1.5f, 1.5f, 1.5f);
	glVertex3f(1.5f, -1.5f, 1.5f);
	//B
	glNormal3f(0.0f, 0.0f, -1.0f);
	glVertex3f(-1.5f, -1.5f, -1.5f);
	glVertex3f(-1.5f, 1.5f, -1.5f);
	glVertex3f(1.5f, 1.5f, -1.5f);
	glVertex3f(1.5f, -1.5f, -1.5f);
	//L
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glVertex3f(-1.5f, -1.5f, -1.5f);
	glVertex3f(-1.5f, -1.5f, 1.5f);
	glVertex3f(-1.5f, 1.5f, 1.5f);
	glVertex3f(-1.5f, 1.5f, -1.5f);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.256777, 0.137622, 0.086014 }, { 12.8 }, { 0.19125, 0.0735, 0.0225 }, { 0.7038, 0.27048, 0.0828 }, 6.8, 10.0, 0.0);
	glutSolidSphere(1.7, 20, 20);
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.628281, 0.555802, 0.366065 }, { 51.2 }, { 0.24725, 0.1995, 0.0745 }, { 0.75164, 0.60648, 0.22648 }, 6.8, 5.0, 0.0);
	glutSolidSphere(1.4, 20, 20);
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.3333, 0.3333, 0.521569 }, { 9.84615 }, { 0.10588, 0.058824, 0.113725 }, { 0.427451, 0.470588, 0.541176 }, 0.0, 10.0, 0.0);
	glutSolidSphere(1.4, 20, 20);
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.508273, 0.508273, 0.508273 }, { 51.2 }, { 0.19225, 0.19225, 0.19225 }, { 0.50754, 0.50754, 0.50754 }, 0.0, -0.5, 0.0);
	glutSolidSphere(1.4, 20, 20);
	glPopMatrix();

	glPushMatrix();
	pintar({ 0.773911, 0.773911, 0.773911 }, { 89.6 }, { 0.23125, 0.23125, 0.23125 }, { 0.2775, 0.2775, 0.2775 }, 7.0, -1.5, 0.0);
	glRotatef(-90, 1.0, 0.0, 0.0);
	drawCylinder(1.0, 1.0, 3.0, 20.0, 20.0);
	//glutSolidSphere(1.0, 20, 20);
	glPopMatrix();
	glPopMatrix();
	glFlush();
}

void reshape(int w, int h) {
	// Set the viewport size, based on function input 
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size 
	glMatrixMode(GL_PROJECTION);
	// first set as identity 
	glLoadIdentity();
	// then set perspective projection parameters based 
	// on aspect ratio 
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 50.0);
	// Set the model view matrix to identity 
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	

	// Set the "look at" point 
	//Ojo , objetivo, 
	gluLookAt(0.0, 9.0, 40.0, 0.0, 5, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key)
	{
		// Use "Esc" key to exit
	case 27:
		exit(0);
		break;
	case 'q':
		white = false;
		glDisable(GL_LIGHT0);
		glEnable(GL_LIGHT1);
		break;
	case 'w':
		white = true;
		glDisable(GL_LIGHT1);
		glEnable(GL_LIGHT0);		
		break;
	case '2':
		iint -= 0.1;
		break;
	case '1':
		iint += 0.1;
		break;
	case 'a':
		rota++;
		break;
	case 's':
		rota--;
		break;
	case 'z':
		zz += 0.2;
		break;
	case 'Z':
		zz -= 0.2;
		break;
	case 'd':
		fogDensity += 0.01;
		break;
	case 'D':
		fogDensity -= 0.01;
		break;
	case 'f':
		fog = !fog;
		break;
	}

	//glMatrixMode(GL_MODELVIEW);
	//glLoadIdentity();
	glutPostRedisplay();
}

void processSpecialKeys(int key, int x, int y) {

	switch (key) {
	case GLUT_KEY_UP:
		yy += 0.02;
		//dir[1] += spotInc;
		//glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir);
		break;
	case GLUT_KEY_DOWN:
		yy -= 0.02;
		//dir[1] -= spotInc;
		//glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir);
		break;
	case GLUT_KEY_LEFT:
		xx -= 0.02;
		//dir[0] -= spotInc;
		//glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir);
		break;
	case GLUT_KEY_RIGHT:
		xx += 0.02;
		//dir[0] += spotInc;
		//glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, dir);
		break;
	}
	glutPostRedisplay();
}


int main(int argc, char** argv) {
	// GLUT INITIALIZATION 
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("mainlightsA01421349");

	// Additional initalization 
	init();

	// Register callback functions 
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(processSpecialKeys);
	glutIdleFunc(display);

	// Do main loop 
	glutMainLoop();

	// Exit
	return 0;
}

