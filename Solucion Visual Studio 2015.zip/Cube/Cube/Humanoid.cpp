#include <windows.h>
#include <math.h>
#include <GL/gl.h>
//#include <GL/glut.h>
#include <iostream>
#include <ctime> 
#include <array>
#include <vector>
#include "glut.h"

typedef	struct node {
	void(*transform)();
	void(*draw)();
	struct node *child;
	struct node *sibling;
}node;


void traverse(node *root) {
	glPushMatrix();

	root->transform();
	root->draw();

	if (root->child != NULL)
	{
		traverse(root->child);
	}

	glPopMatrix();

	if (root->sibling != NULL)
		traverse(root->sibling);
}

node root;

node root2;

node root3;

node root4;


node torzo;
float angleTorzo;

node cabeza;
float angleCabeza;

node hombro;
float angleHombro;

node hombro2;
//float angleHombro;

node brazo;
float angleBrazo;

node brazo2;
//float angleBrazo;

node muneca;
float angleMuneca;

node muneca2;
//float angleMuneca;

node mano;
float angleMano;

node dedo1;
float angleDedo;

node dedo2;
//float angleDedo;

node pulgar1;
float anglePulgar;

node dedo3;
//float angleDedo;

node dedo4;
//float angleDedo;

node pulgar2;
//float angleDedo;


void RenderRoot() {
	
}

void RenderRoot2() {
	
}

void RenderRoot3() {
	
}

void RenderRoot4() {
	
}

void TransformRoot() {
	glTranslated(-5.0, 0.0, 0.0);
}

void TransformRoot2() {
	glTranslated(5.0, 0.0, 0.0);
}

void TransformRoot3() {
	glTranslated(5.0, 0.0, -5.0);
}

void TransformRoot4() {
	glTranslated(-5.0, 0.0, -5.0);
}

void RenderTorzo() {
	glPushMatrix();
	glTranslatef(0.0, 0.0, 0.0);
	glScalef(2.4, 3.0, 1.0);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforTorzo() {
	glRotatef(angleTorzo, 0.0, 1.0, 0.0);
}

void RenderCabeza() {
	glPushMatrix();
	glTranslatef(0.0, 2.4, 0.0);
	glutWireSphere(1.0, 15, 12);
	glPopMatrix();
}

void TransforCabeza() {
	glRotatef(angleCabeza, 0.0, 1.0, 0.0);
}

void RenderHombro1() {
	glPushMatrix();
	glTranslatef(-1.0, 1.2, 0.0);
	glScalef(1.5, 0.5, 0.5);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforHombro1() {
	glTranslatef(-1.0, 0.0, 0.0);
	glRotatef(angleHombro, 0.0, 1.0, 0.0);
}

void RenderHombro2() {
	glPushMatrix();
	glTranslatef(1.0, 1.2, 0.0);
	glScalef(1.5, 0.5, 0.5);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforHombro2() {
	glTranslatef(1.0, 0.0, 0.0);
	glRotatef(-angleHombro, 0.0, 1.0, 0.0);
}

void RenderBrazo1() {
	glPushMatrix();
	glTranslatef(-1.0, 0.0, 0.0);

	glScalef(1.5, 0.5, 0.5);
	glutSolidCube(1.0);

	glPopMatrix();
}

void TransforBrazo1() {
	glTranslatef(-1.5, 1.2, 0.0);
	glRotatef(-90.0, 0.0, 0.0, 1.0);
	glRotatef(angleBrazo, 0.0, 0.0, 1.0);
}

void RenderMuneca1() {
	//glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(0.0, 0.0, 0.0);
	glScalef(0.2, 0.5, 0.5);	
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforMuneca1() {
	glTranslatef(-1.9, 0.0, 0.0);
	glRotatef(angleMuneca, 1.0, 0.0, 0.0);
}

void RenderDedo1() {
	glPushMatrix();
	glTranslatef(-0.3, 0.0, 0.0);
	glScalef(1, 0.2, 0.1);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforDedo1() {
	glTranslatef(-0.2, 0.0, 0.1);
	glRotatef(angleDedo, 0.0, 1.0, 0.0);
}

void RenderDedo2() {
	glPushMatrix();
	glTranslatef(-0.3, 0.0, 0.0);
	glScalef(1, 0.2, 0.1);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforDedo2() {
	glTranslatef(-0.2, 0.0, -0.1);
	glRotatef(-angleDedo, 0.0, 1.0, 0.0);
}

void RenderPulgar1() {
	glPushMatrix();
	glTranslatef(0.0, -0.2, 0.0);
	glScalef(0.2, 0.6, 0.1);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforPulgar1() {
	glTranslatef(0.0, -0.2, 0.0);
	glRotatef(anglePulgar, 0.0, 0.0, 1.0);
}

void RenderBrazo2() {
	glPushMatrix();
	glTranslatef(1.0, 0.0, 0.0);
	glScalef(1.5, 0.5, 0.5);
	glutSolidCube(1.0);

	glPopMatrix();
}

void TransforBrazo2() {
	glTranslatef(1.5, 1.2, 0.0);
	glRotatef(90.0, 0.0, 0.0, 1.0);
	glRotatef(-angleBrazo, 0.0, 0.0, 1.0);
}

void RenderMuneca2() {
	//glColor3f(1, 0, 0);
	glPushMatrix();
	glTranslatef(0.0, 0.0, 0.0);
	glScalef(0.2, 0.5, 0.5);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforMuneca2() {
	glTranslatef(1.9, 0.0, 0.0);
	glRotatef(angleMuneca, 1.0, 0.0, 0.0);
}

void RenderDedo3() {
	glPushMatrix();
	glTranslatef(0.3, 0.0, 0.0);
	glScalef(1, 0.2, 0.1);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforDedo3() {
	glTranslatef(0.2, 0.0, 0.1);
	glRotatef(-angleDedo, 0.0, 1.0, 0.0);
}

void RenderDedo4() {
	glPushMatrix();
	glTranslatef(0.3, 0.0, 0.0);
	glScalef(1, 0.2, 0.1);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforDedo4() {
	glTranslatef(0.2, 0.0, -0.1);
	glRotatef(angleDedo, 0.0, 1.0, 0.0);
}

void RenderPulgar2() {
	glPushMatrix();
	glTranslatef(0.0, -0.2, 0.0);
	glScalef(0.2, 0.6, 0.1);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforPulgar2() {
	glTranslatef(0.0, -0.2, 0.0);
	glRotatef(-anglePulgar, 0.0, 0.0, 1.0);
}


void CreateShape() {
	root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = &torzo;
	root.sibling = &root2;

	root2.draw = RenderRoot2;
	root2.transform = TransformRoot2;
	root2.child = &torzo;
	root2.sibling = &root3;

	root3.draw = RenderRoot3;
	root3.transform = TransformRoot3;
	root3.child = &torzo;
	root3.sibling = &root4;

	root4.draw = RenderRoot4;
	root4.transform = TransformRoot4;
	root4.child = &torzo;
	root4.sibling = NULL;

	torzo.draw = RenderTorzo;
	torzo.transform = TransforTorzo;
	torzo.child = &cabeza;
	//torzo.child = &hombro;
	torzo.sibling = NULL;

	cabeza.draw = RenderCabeza;
	cabeza.transform = TransforCabeza;
	cabeza.child = NULL;
	cabeza.sibling = &hombro;

	hombro.draw = RenderHombro1;
	hombro.transform = TransforHombro1;
	hombro.child = &brazo;
	hombro.sibling = &hombro2;

	brazo.draw = RenderBrazo1;
	brazo.transform = TransforBrazo1;
	brazo.child = &muneca;
	brazo.sibling = NULL;

	muneca.draw = RenderMuneca1;
	muneca.transform = TransforMuneca1;
	muneca.child = &dedo1;
	muneca.sibling = NULL;

	dedo1.draw = RenderDedo1;
	dedo1.transform = TransforDedo1;
	dedo1.child = NULL;
	dedo1.sibling = &dedo2;

	dedo2.draw = RenderDedo2;
	dedo2.transform = TransforDedo2;
	dedo2.child = NULL;
	dedo2.sibling = &pulgar1;

	pulgar1.draw = RenderPulgar1;
	pulgar1.transform = TransforPulgar1;
	pulgar1.child = NULL;
	pulgar1.sibling = NULL;

	hombro2.draw = RenderHombro2;
	hombro2.transform = TransforHombro2;
	hombro2.child = &brazo2;
	hombro2.sibling = NULL;

	brazo2.draw = RenderBrazo2;
	brazo2.transform = TransforBrazo2;
	brazo2.child = &muneca2;
	brazo2.sibling = NULL;

	muneca2.draw = RenderMuneca2;
	muneca2.transform = TransforMuneca2;
	muneca2.child = &dedo3;
	muneca2.sibling = NULL;

	dedo3.draw = RenderDedo3;
	dedo3.transform = TransforDedo3;
	dedo3.child = NULL;
	dedo3.sibling = &dedo4;

	dedo4.draw = RenderDedo4;
	dedo4.transform = TransforDedo4;
	dedo4.child = NULL;
	dedo4.sibling = &pulgar2;

	pulgar2.draw = RenderPulgar2;
	pulgar2.transform = TransforPulgar2;
	pulgar2.child = NULL;
	pulgar2.sibling = NULL;
}

void init(void)
{
	// Define material properties 
	GLfloat mat_spec[] = { 3000.0, 3000.0, 3000.0, 3000.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 1.0, 0.0, 0.0 };

	// Set light properties ... 
	GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
	// and create two lights at two positions 
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_posl[] = { -1.0, -1.0, 1.0, 0.0 };

	// Set clear (background) color 
	glClearColor(0.0, 0.0, 0.0, 0.0);

	// Set shading model to use 
	glShadeModel(GL_SMOOTH);

	// Set material properties, as defined above 
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);

	// Finish setting up the two lights (position, 
	// and component values (specular and diffuse)) 
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_posl);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

	// Enable lighting 
	glEnable(GL_LIGHTING);
	// Act�vate (enable) individual lights 
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	// Enable depth testing (for hidden surface removal) 
	glEnable(GL_DEPTH_TEST);

	/*root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = NULL;
	root.sibling = NULL;*/

	CreateShape();
}

void display(void) {
	// Clear the buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Get model - from library 
	//glutSolidTeapot(0.80);
	glPushMatrix();
	//glRotatef(7.0, 0.0, 1.0, 0.0);
	traverse(&root);
	glPopMatrix();
	glFlush();
}

void reshape(int w, int h) {
	// Set the viewport size, based on function input 
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size 
	glMatrixMode(GL_PROJECTION);
	// first set as identity 
	glLoadIdentity();
	// then set perspective projection parameters based 
	// on aspect ratio 
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 50.0);
	// Set the model view matrix to identity 
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// Set the "look at" point 
	//Ojo , objetivo, 
	gluLookAt(0.0, 9.0, 40.0, 0.0, 5, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key)
	{
		// Use "Esc" key to exit
	case 27:
		exit(0);
		break;

	case 't':
		angleTorzo += 4.0;
		break;
	case 'T':
		angleTorzo -= 4.0;
		break;
	case 'h':
		angleHombro += 4.0;
		break;
	case 'H':
		angleHombro -= 4.0;
		break;
	case 'b':
		angleBrazo += 4.0;
		break;
	case 'B':
		angleBrazo -= 4.0;
		break;
	case 'm':
		angleMuneca += 4.0;
		break;
	case 'M':
		angleMuneca -= 4.0;
		break;
	case 'c':
		angleCabeza += 4.0;
		break;
	case 'C':
		angleCabeza -= 4.0;
		break;
	case 'd':
		angleDedo += 4.0;
		break;
	case 'D':
		angleDedo -= 4.0;
		break;
	case 'p':
		anglePulgar -= 4.0;
		break;
	case 'P':
		anglePulgar += 4.0;
		break;
	}

	glutPostRedisplay();
}


int main(int argc, char** argv) {
	// GLUT INITIALIZATION 
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Robot Humanoid");

	// Additional initalization 
	init();

	// Register callback functions 
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(display);

	// Do main loop 
	glutMainLoop();

	// Exit
	return 0;
}

