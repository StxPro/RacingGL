//
//  Reader.h
//  Cragra Modelo OpenGL
//
//  Created by Javier Dalma on 4/20/17.
//  Copyright © 2017 Javier Dalma. All rights reserved.
//

#ifndef Reader_h
#define Reader_h



#define MAX_VERT 100000

struct Vertex {
    
    float x;
    float y;
    float z;
    
};


class Reader {
private:
    Vertex vertex[256];
    
public:
    Reader();
    ~Reader();
    
    void load(char* filename);
    void draw(char* filename);
    
    
};


#endif /* Reader_h */
