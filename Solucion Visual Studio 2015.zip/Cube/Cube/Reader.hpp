//
//  Reader.hpp
//  Cragra Modelo OpenGL
//
//  Created by Javier Dalma on 4/20/17.
//  Copyright © 2017 Javier Dalma. All rights reserved.
//

#ifndef Reader_hpp
#define Reader_hpp

#include <stdio.h>

#endif /* Reader_hpp */
