//
//  main.cpp
//  RacingGL
//
//  Created by Javier Dalma on 3/29/17.
//  Copyright © 2017 Javier Dalma. All rights reserved.
//

#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <GL/gl.h>
#include "glut.h"  
#include <iostream>
#include <fstream>
#include <assert.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
//#include <MMSystem.h>

struct Vertex
{
	float x, y, z;
};

Vertex lento[30];
Vertex danio[30];
Vertex vida[30];
Vertex rapido[30];

static int width;
static int height;

float zP1=298.0f;
float zP2=298.0f;

float xP1=1.0f;
float xP2=-1.0f;


float increasPosition=0.1f;


bool isCollidingXRight = false;
bool isCollidingXLeft = false;
bool isCollidingZFront = false;
bool isCollidingZBack = false;

bool collission = false;

bool col1Left = false;
bool col1Right = false;
bool col1Front = false;

bool col2Left = false;
bool col2Right = false;
bool col2Front = false;



float redCubeCamPosZ=301.0;
float redCubeCamPosX=1.0;

float blueCubeCamPosZ=301.0;
float blueCubeCamPosX=-1.0;


float v1 = 0.005;
float v2 = 0.005;

float vida1 = 7.0;
float vida2 = 7.0;

bool izq1 = false;
bool izq2 = false;
bool der1 = false;
bool der2 = false;

void genObjects() {
	srand(time(NULL));
	int x, z;
	for (int i = 0; i < 30; i++) {
		//srand(time(NULL));
		z = rand() % 290 + 1;  //in the range 1 to 100
		x = rand() % 10 + (-5);  //in the range -5 a 5
		lento[i].x = x;
		lento[i].y = 0.5;
		lento[i].z = z;


		printf(" Lento x: %i z: %i \n", x, z);

		z = rand() % 290 + 1;  //in the range 1 to 100
		x = rand() % 10 + (-5);  //in the range -5 a 5
		rapido[i].x = x;
		rapido[i].y = 0.5;
		rapido[i].z = z;

		printf(" Repido x: %i z: %i \n", x, z);

		z = rand() % 290 + 1;  //in the range 1 to 100
		x = rand() % 10 + (-5);  //in the range -5 a 5
		danio[i].x = x;
		danio[i].y = 0.5;
		danio[i].z = z;

		printf(" Danio x: %i z: %i \n", x, z);

		
		z = rand() % 290 + 1;  //in the range 1 to 100
		x = rand() % 10 + (-5);  //in the range -5 a 5
		vida[i].x = x;
		vida[i].y = 0.5;
		vida[i].z = z;

		printf(" Vida x: %i z: %i \n", x, z);
	}
}


#pragma region "Modelo jerarquico coches"

typedef struct treenode {
	// Transform
	void(*transform)();
	// Render
	void(*draw)();
	// Child
	struct treenode *child;
	// Sibling
	struct treenode *sibling;
} treenode;

//4 roots
treenode root;
treenode root2;


//car body
treenode carBody;

//carFront
treenode carFront;

//right tire
treenode rightFrontTire;
treenode rightBackTire;


//left arm
treenode leftFrontTire;
treenode leftBackTire;


//Angle for base
static float angle10 = 0.0;



// Set the increment
static float angleIncrement = 5.0;


void drawCylinder(GLdouble baseRadius,
	GLdouble topRadius,
	GLdouble height,
	GLint slices,
	GLint stacks)
{
	GLUquadricObj *qobj;
	qobj = gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluCylinder(qobj, baseRadius, topRadius, height, slices, stacks);
}
//---------------------------------------------------------------------------------------Draw Car--------------------------------------------

//DrawCarBody-----------------------------------------------
void DrawCarBody(void)
{
	glPushMatrix();
	glTranslated(0.0, 2, 0.0);
	glScalef(2.0, 2, 3.0);
	glutSolidCube(1.0);
	glPopMatrix();
}

//DrawCarHead-----------------------------------------------
void DrawCarHead(void)
{
	glPushMatrix();
	glTranslated(0, 1.5, -2);
	glScalef(2, 1, 1);
	glutSolidCube(1);
	glPopMatrix();
}

//DrawRightFrontTire-----------------------------------------------------------------------------
void DrawRightFrontTire(void)
{
	glPushMatrix();
	glRotated(90, 0, 1, 0);
	glTranslated(1.5, 1.0, 1);
	drawCylinder(0.5, 0.5, 0.5, 10, 10);
	glPopMatrix();

}

//DrawLeftFrontTire-----------------------------------------------------------------------------
void DrawLeftFrontTire(void)
{
	glPushMatrix();
	glRotated(90, 0, 1, 0);
	glTranslated(1.5, 1.0, -1.5);
	drawCylinder(0.5, 0.5, 0.5, 10, 10);
	glPopMatrix();

}

//DrawRightBackTire-----------------------------------------------------------------------------
void DrawRightBackTire(void)
{
	glPushMatrix();
	glRotated(90, 0, 1, 0);
	glTranslated(-1, 1.0, 1);
	drawCylinder(0.5, 0.5, 0.5, 10, 10);
	glPopMatrix();
}

//DrawRightBackTire-----------------------------------------------------------------------------
void DrawLeftBackTire(void)
{
	glPushMatrix();
	glRotated(90, 0, 1, 0);
	glTranslated(-1, 1.0, -1.5);
	drawCylinder(0.5, 0.5, 0.5, 10, 10);
	glPopMatrix();

}



//--------------------------------------------------------------------------Body Transformations---------------------------------------------------------------------------------------

//Base Transformation--------------------------------------------------------------------------
void CarBody() {
	glRotatef(angle10, 0.0, 1.0, 0.0);
}

//Head Transformation--------------------------------------------------------------------------
void FrontPartCar() {
	glRotatef(0, 0.0, 1.0, 0.0);
}

//Right Hand Transfromations--------------------------------------------------------------------------

void TransformRightFrontTire() {
	//DontMove
}

void TransformLeftFrontTire() {
	//DontMove
}

void TransformRightBackTire() {
	//DontMove
}


void TransformLeftBackTire() {
	//DontMove
}





void TransformLeftElbowToWrist() {
	//DontMove
}

void TransformLeftWristToHand() {
	//DontMove
}


//Car Starting Positions--------------------------------------------------------------------------
void TransformR1() {
	//glTranslated(-4.0, 0.0, 0.0);
	//glTranslated(xP1, 0.0, zP1);
	
}

void TransformR2() {
	glTranslated(4.0, 0.0, 0.0);
}




void DrawNothing() {

}



void CreateRobot()
{

	//Root
	root.transform = TransformR1;
	root.draw = DrawNothing;
	root.child = &carBody;
	root.sibling = NULL;

	/*root2.transform = TransformR2;
	root2.draw = DrawNothing;
	root2.child = &carBody;
	root2.sibling = NULL;*/


	//CarBody
	carBody.transform = CarBody;
	carBody.draw = DrawCarBody;
	carBody.child = &carFront;
	carBody.sibling = NULL;

	//CarFrontPart
	carFront.transform = FrontPartCar;
	carFront.draw = DrawCarHead;
	carFront.child = NULL;
	carFront.sibling = &rightFrontTire;


	//RightFrontTire
	rightFrontTire.transform = TransformRightFrontTire;
	rightFrontTire.draw = DrawRightFrontTire;
	rightFrontTire.child = NULL;
	rightFrontTire.sibling = &leftBackTire;

	//LeftBackTire
	leftBackTire.transform = TransformLeftBackTire;
	leftBackTire.draw = DrawLeftBackTire;
	leftBackTire.child = NULL;
	leftBackTire.sibling = &rightBackTire;

	//RightBackTire
	rightBackTire.transform = TransformRightBackTire;
	rightBackTire.draw = DrawRightBackTire;
	rightBackTire.child = NULL;
	rightBackTire.sibling = &leftFrontTire;


	//LeftFrontTire
	leftFrontTire.transform = TransformLeftFrontTire;
	leftFrontTire.draw = DrawLeftFrontTire;
	leftFrontTire.child = NULL;
	leftFrontTire.sibling = NULL;



}

void traverse(treenode *node)
{
	glPushMatrix();
	// Transform
	node->transform();
	// Draw
	node->draw();
	// Child
	if (node->child != NULL) traverse(node->child);
	glPopMatrix();
	// Sibling
	if (node->sibling != NULL) traverse(node->sibling);
}
#pragma endregion

void DrawObjetos() {
	float distance1 , distance2;
	for (int i = 0; i < 30; i++) {
		distance1 = sqrt((lento[i].x - (xP1 + 0.0))*(lento[i].x - (xP1 + 0.0)) + (lento[i].z - zP1)*(lento[i].z - zP1));
		distance2 = sqrt((lento[i].x - (xP2 + 0.0))*(lento[i].x - (xP2 + 0.0)) + (lento[i].z - zP2)*(lento[i].z - zP2));
		if (distance1 > 1 && distance2 > 1) {
			glPushMatrix();
			glTranslated(lento[i].x, lento[i].y, lento[i].z);
			glColor3f(0.7, 0.3, 0.0);
			glutSolidSphere(0.5, 10, 10);
			glPopMatrix();
		}
		else {
			lento[i].y = 2.5;
			if (distance1 <= 1) v1 -= 0.000001;
			if (distance2 <= 1) v2 -= 0.000001;
		}
		
		distance1 = sqrt((rapido[i].x - (xP1 + 0.0))*(rapido[i].x - (xP1 + 0.0)) + (rapido[i].z - zP1)*(rapido[i].z - zP1));
		distance2 = sqrt((rapido[i].x - (xP2 + 0.0))*(rapido[i].x - (xP2 + 0.0)) + (rapido[i].z - zP2)*(rapido[i].z - zP2));
		if (distance1 > 1 && distance2 > 1) {
			glPushMatrix();
			glTranslated(rapido[i].x, rapido[i].y, rapido[i].z);
			glColor3f(0.2, 0.4, 0.7);
			glutSolidSphere(0.5, 10, 10);
			glPopMatrix();
		}
		else {
			rapido[i].y = 2.5;
			if (distance1 <= 1) v1 += 0.000001;
			if (distance2 <= 1) v2 += 0.000001;
		}

		/*glPushMatrix();
		glTranslated(rapido[i].x, -0.5, rapido[i].z);
		glColor3f(0.2, 0.4, 0.7);
		glutSolidSphere(0.5, 10, 10);
		glPopMatrix();*/


		distance1 = sqrt((danio[i].x - (xP1 + 0.0))*(danio[i].x - (xP1 + 0.0)) + (danio[i].z - zP1)*(danio[i].z - zP1));
		distance2 = sqrt((danio[i].x - (xP2 + 0.0))*(danio[i].x - (xP2 + 0.0)) + (danio[i].z - zP2)*(danio[i].z - zP2));
		if (distance1 > 1 && distance2 > 1) {
			glPushMatrix();
			glTranslated(danio[i].x, danio[i].y, danio[i].z);
			glColor3f(0.9, 0.2, 0.1);
			glutSolidSphere(0.5, 10, 10);
			glPopMatrix();
		}
		else {
			danio[i].y = 2.5;
			if (distance1 <= 1) vida1 -= 0.002;
			if (distance2 <= 1) vida2 -= 0.002;
		}

		/*glPushMatrix();
		glTranslated(danio[i].x, -0.5, danio[i].z);
		glColor3f(0.9, 0.2, 0.1);
		glutSolidSphere(0.5, 10, 10);
		glPopMatrix();*/
		if (i < 9) {
			distance1 = sqrt((vida[i].x - (xP1 + 0.0))*(vida[i].x - (xP1 + 0.0)) + (vida[i].z - zP1)*(vida[i].z - zP1));
			distance2 = sqrt((vida[i].x - (xP2 + 0.0))*(vida[i].x - (xP2 + 0.0)) + (vida[i].z - zP2)*(vida[i].z - zP2));
			if (distance1 > 1 && distance2 > 1) {
				glPushMatrix();
				glTranslated(vida[i].x, vida[i].y, vida[i].z);
				glColor3f(0.1, 0.9, 0.2);
				glutSolidSphere(0.5, 10, 10);
				glPopMatrix();
			}
			else {
				vida[i].y = 2.5;
				if (distance1 <= 1 && vida1 < 7.0) vida1 += 0.002;
				if (distance2 <= 1 && vida2 < 7.0) vida2 += 0.002;
			}
		}		


		/*glPushMatrix();
		glTranslated(vida[i].x, -0.5, vida[i].z);
		glColor3f(0.1, 0.9, 0.2);
		glutSolidSphere(0.5, 10, 10);
		glPopMatrix();*/
	}
}

void DrawVida(float vida) {
	float esp = 0.5;
	for (int i = lround(vida); i > 0; i--) {
		glPushMatrix();
		glTranslated(redCubeCamPosX - 4.0 + i, 3.5, redCubeCamPosZ - 5);
		glColor3f(0.3, 0.8, 0.2);
		glutSolidSphere(0.2, 10, 10);
		glPopMatrix();
	}
}

void DrawVida2(float vida) {
	float esp = 0.5;
	for (int i = lround(vida); i > 0; i--) {
		glPushMatrix();
		glTranslated(blueCubeCamPosX - 4.0 + i, 3.5, blueCubeCamPosZ - 5);
		glColor3f(0.2, 0.9, 0.4);
		glutSolidSphere(0.2, 10, 10);
		glPopMatrix();
	}
}

void DrawCar1(){
    //---------------------------Viewport 1------------------------------------
	glPushMatrix();
    glViewport(0, 0, width/2, height);
    glLoadIdentity();
	//gluPerspective(20.0, (GLfloat)width / (GLfloat)height, 0.10, 50.0);
	//glTranslated(xP1, 0.0, zP1);
	gluLookAt(redCubeCamPosX, 1.0, redCubeCamPosZ, redCubeCamPosX, 0.0, -1.0, 0.0, 1.0, 0.0);
	//gluLookAt(redCubeCamPosX, 0.0, redCubeCamPosZ+5, redCubeCamPosX, 0.0, -1.0, 0.0, 1.0, 0.0);
	

    
    
    glPushMatrix();
    glTranslated(xP2, -0.5, zP2);
    glColor3f(0, 0, 1);
	//glutWireSphere(0.2, 10, 10);
	glScalef(0.5, 0.5, 0.5);
	traverse(&root);
	glPopMatrix();
	
	DrawObjetos();

	glPushMatrix();
	glTranslated(xP1, -0.5, zP1);
	glColor3f(1, 0, 0);
	//glutWireSphere(0.2, 10, 10);
	glScalef(0.5, 0.5, 0.5);
	traverse(&root);
	glPopMatrix();


	DrawVida(vida1);

	glPopMatrix();
    
}

void DrawCar2(){
    //----------------------------Viewport 2-----------------------------------
	glPushMatrix();
    glViewport(width/2, 0, width/2, height);
    glLoadIdentity();
	//gluPerspective(20.0, (GLfloat)width/2 / (GLfloat)height, 0.10, 50.0);
    //gluLookAt(blueCubeCamPosX, 0.0, blueCubeCamPosZ, blueCubeCamPosX, 0.0, 0, 0.0, 1.0, 0.0);
	gluLookAt(blueCubeCamPosX, 1.0, blueCubeCamPosZ, blueCubeCamPosX, 0.0, -1.0, 0.0, 1.0, 0.0);

	

    /*glPushMatrix();
    glTranslated(xP1, 0.0, zP1);
    glColor3f(1, 0, 0);
    glutWireCube(0.2);
    glPopMatrix();*/
	glPushMatrix();
	glTranslated(xP1, -0.5, zP1);
	glColor3f(1, 0, 0);
	//glutWireSphere(0.2, 10, 10);
	glScalef(0.5, 0.5, 0.5);
	traverse(&root);
	glPopMatrix();


	DrawObjetos();

	glPushMatrix();
	glTranslated(xP2, -0.5, zP2);
	glColor3f(0, 0, 1);
	//glutWireCube(0.2);
	glScalef(0.5, 0.5, 0.5);
	traverse(&root);
	glPopMatrix();
    
	DrawVida2(vida2);

	glPopMatrix();
}

void DrawPista() {

}




void CheckCollisions(){

	col1Left = (xP1 <= (xP2 + 1.5) && xP1 >= (xP2 + 1.0) && zP1 <= (zP2 + 1.0) && zP1 >= (zP2 - 1.2));
	col1Right = (xP1 >= (xP2 - 1.5) && xP1 <= (xP2 - 1.0) && zP1 <= (zP2 + 1.0) && zP1 >= (zP2 - 1.2));
	//if (xP1 >= (xP2 + 1.0)) printf("111111111");
	//if (col1Right) printf("colision coche 1 Derecha");
	//if (col1Left) printf("colision coche 1 Izquierda");
	//col1Front = false;
	col1Front = (xP1 <= (xP2 + 1.5) && xP1 >= (xP2 - 1.5) && zP1 >= (zP2 + 0.8) && zP1 <= (zP2 + 1.2));
	//if (col1Front) printf("colision coche 1 EnFrente");

	col2Front = (xP1 <= (xP2 + 1.5) && xP1 >= (xP2 - 1.5) && zP2 >= (zP1 + 0.8) && zP2 <= (zP1 + 1.2));
	//if (col2Front) printf("colision coche 2 EnFrente");

}


static void display(void) {
    glClear(GL_COLOR_BUFFER_BIT);
    //glColor3f(1.0f, 0.0f, 0.0f);
	if (!col1Front) {
		zP1 -= v1;
		redCubeCamPosZ -= v1;
	}
	if (!col2Front) {
		zP2 -= v2;
		blueCubeCamPosZ -= v2;
	}	
    DrawCar1();
    DrawCar2();
	
    CheckCollisions();

	if (izq1 && (!col1Left  && xP1 >= -5)) {
		xP1 -= 0.007;
		redCubeCamPosX -= 0.007;
	}

	if (der1 && (!col1Right  && xP1 <= 5)) {
		xP1 += 0.007;
		redCubeCamPosX += 0.007;
	}

	if (der2 && (!col1Left && xP2 <= 5)) {
		xP2 += 0.007;
		blueCubeCamPosX += 0.007;
	}

	if (izq2 && (!col1Right && xP2 >= -5)) {
		xP2 -= 0.007;
		blueCubeCamPosX -= 0.007;
	}
	int vida1int = lround(vida1);
	//printf(" Vida 1: %i 1: %f \n", vida1int, vida2);

    glFlush();
}

static void reshape(int w, int h) {
    width = w;
    height = h;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
    glMatrixMode(GL_MODELVIEW);
}



void player1Movement(unsigned char key, int x, int y) {
	switch (key)
	{

		//--------------------------Player 1 Movement---------------------------------
	case 'w':
		if (!col1Front) {
			zP1 -= increasPosition;
			redCubeCamPosZ -= increasPosition;
			printf(" gllookat %f,%f,%f,%f,%f,%f \n", redCubeCamPosX, 0.0, redCubeCamPosZ, redCubeCamPosX, 0.0, -1.0);
		}
		break;

	case 's':
		if (!col2Front) {
			zP1 += increasPosition;
			redCubeCamPosZ += increasPosition;
		}
		break;

	case 'a':
		/*if (!col1Left  && xP1 >= -5) {
			xP1 -= increasPosition;
			redCubeCamPosX -= increasPosition;
			
		}*/
		izq1 = true;
		break;


	case 'd':
		/*if (!col1Right  && xP1 <= 5) {
			xP1 += increasPosition;
			redCubeCamPosX += increasPosition;
		}*/
		der1 = true;
		break;

		//--------------------------Player 2 Movement---------------------------------

	case 'u':
		if (!col2Front) {
			zP2 -= increasPosition;
			blueCubeCamPosZ -= increasPosition;
		}
		break;

	case 'j':
		if (!col1Front) {
			zP2 += increasPosition;
			blueCubeCamPosZ += increasPosition;
		}
		break;

	case 'k':
		/*if (!col1Left && xP2 <= 5) {
			xP2 += increasPosition;
			blueCubeCamPosX += increasPosition;
		}*/
		der2 = true;
		break;

	case 'h':
		/*if (!col1Right && xP2 >= -5) {
			xP2 -= increasPosition;
			blueCubeCamPosX -= increasPosition;
		}*/
		izq2 = true;
		break;

		//--------------------------Quit---------------------------------
	case 27:
		exit(0);
		break;
	}

	glutPostRedisplay();
}

void player1Movement2(unsigned char key, int x, int y) {
	switch (key)
	{

		//--------------------------Player 1 Movement---------------------------------
	case 'w':
		break;

	case 's':
		break;

	case 'a':
		izq1 = false;
		break;


	case 'd':
		der1 = false;
		break;

		//--------------------------Player 2 Movement---------------------------------

	case 'u':
		break;

	case 'j':
		break;

	case 'k':
		der2 = false;
		break;

	case 'h':
		izq2 = false;
		break;

		//--------------------------Quit---------------------------------
	case 27:
		exit(0);
		break;
	}

	glutPostRedisplay();
}


int main(int argc, char** argv) {
        // GLUT INITIALIZATION
        glutInit(&argc, argv);
        glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
        glutInitWindowSize(800, 600);
        glutInitWindowPosition(100, 100);
        glutCreateWindow("RaceGL");

		CreateRobot();
		genObjects();
		//sndPlaySound(TEXT("breakout.mp3"), SND_ASYNC);
		//PlaySound(TEXT("breakout.mp3"), NULL, SND_SYNC);
        
        // Register callback functions
        glutDisplayFunc(display);
        glutReshapeFunc(reshape);
		glutKeyboardFunc(player1Movement);
		glutKeyboardUpFunc(player1Movement2);
		//glutSetKeyRepeat(1);
       // glutSpecialFunc(player2Movement);
        

		glutIdleFunc(display);
        // Do main loop
        glutMainLoop();
        
        // Exit
        return 0;
}

