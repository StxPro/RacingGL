#include <windows.h>
#include <math.h>
#include <GL/gl.h>
//#include <GL/glut.h>
#include <iostream>
#include <ctime> 
#include <array>
#include <vector>
#include "glut.h"
#include <gl/GLU.h>

typedef	struct node {
	void(*transform)();
	void(*draw)();
	struct node *child;
	struct node *sibling;
}node;

// Global variables for each of the 4 angles
static float angle1 = 0.0;
static float angle2 = 0.0;
static float angle3 = 0.0;
static float angle4 = 0.0;
static float angle5 = 0.0;
static float angle6 = 0.0;
static float angle7 = 0.0;
static float angle8 = 0.0;
// Set the increment
static float angleInc = 3.0;

void traverse(node *root) {
	glPushMatrix();

	root->transform();
	root->draw();

	if (root->child != NULL)
	{
		traverse(root->child);
	}

	glPopMatrix();

	if (root->sibling != NULL)
		traverse(root->sibling);
}

void drawCylinder(GLdouble baseRadius,
	GLdouble topRadius,
	GLdouble height,
	GLint slices,
	GLint stacks)
{
	GLUquadricObj *qobj;
	qobj = gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluCylinder(qobj, baseRadius, topRadius, height,
		slices, stacks);
}

node tree;

node tree1;
node tree2;
node tree3;

node root;

node root2;

node root3;

node root4;

float camX, camY;

// Dimensiones para el cuerpo principal
float bodyx = 3.0;
float bodyy = 2.0;
float bodyz = 1.5;

float largopata = 1.0;
float anchopata = 0.5;
float gruesopata = 0.35;

float largocabeza = 1.0;
float anchocabeza = 1.0;
float gruesocabeza = 1.0;

void RenderRoot() {
	glBegin(GL_QUADS);
	glVertex3f(-2.0f, 0.0f, 2.0f);
	glVertex3f(0.0f, 0.0f, 2.0f);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(-2.0f, 0.0f, 0.0f);

	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, 2.0f);
	glVertex3f(2.0f, 0.0f, 2.0f);
	glVertex3f(2.0f, 0.0f, 0.0f);

	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(2.0f, 0.0f, 0.0f);
	glVertex3f(2.0f, 0.0f, -2.0f);
	glVertex3f(0.0f, 0.0f, -2.0f);

	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, -2.0f);
	glVertex3f(-2.0f, 0.0f, -2.0f);
	glVertex3f(-2.0f, 0.0f, 0.0f);
	glEnd();
}

void RenderTree() {
	glPushMatrix();
	glRotatef(-90, 1.0, 0.0, 0.0);
	drawCylinder(0.2f, 0.18f, 1.75f, 8, 1);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.0, 2.35f, 0.0f);
	glutSolidSphere(0.6, 8, 8);
	glPopMatrix();
}

void TransformTree() {
	glTranslatef(-1.5f, 0.0f, -1.5f);
}

void TransformTree1() {
	glTranslatef(-1.2f, 0.0f, -1.3f);
	glScalef(0.4, 0.45, 1.0);
}

void TransformTree2() {
	glTranslatef(-1.35f, 0.0f, -1.15f);
	glScalef(0.3, 0.35, 1.0);
}

void TransformTree3() {
	glTranslatef(-0.85f, 0.0f, -0.85f);
	glScalef(0.3, 0.25, 1.0);
}

void RenderRoot2() {

}

void RenderRoot3() {
	
}

void RenderRoot4() {
	
}

void TransformRoot() {
	glTranslated(-5.0, 0.0, 0.0);
}

void TransformRoot2() {
	glTranslated(5.0, 0.0, 0.0);
}

void TransformRoot3() {
	glTranslated(5.0, 0.0, -5.0);
}

void TransformRoot4() {
	glTranslated(-5.0, 0.0, -5.0);
}

void RenderBody(void)
{
	glPushMatrix();
	glScalef(bodyx, bodyy, bodyz);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransformBody()
{
	glRotatef(angle1, 0, 1, 0);
}



void RenderTorzo() {
	glPushMatrix();
	glTranslatef(0.0, 0.0, 0.0);
	glScalef(2.4, 3.0, 1.0);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransforTorzo() {
	//glRotatef(angleTorzo, 0.0, 1.0, 0.0);
}


void CreateShape() {
	root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = &tree;
	root.sibling = &root2;

	root2.draw = RenderRoot;
	root2.transform = TransformRoot2;
	root2.child = &tree;
	root2.sibling = &root3;

	root3.draw = RenderRoot;
	root3.transform = TransformRoot3;
	root3.child = &tree;
	root3.sibling = &root4;

	root4.draw = RenderRoot;
	root4.transform = TransformRoot4;
	root4.child = &tree;
	root4.sibling = NULL;

	tree.draw = RenderTree;
	tree.transform = TransformTree;
	tree.child = NULL;
	tree.sibling = &tree1;

	tree1.draw = RenderTree;
	tree1.transform = TransformTree1;
	tree1.child = NULL;
	tree1.sibling = &tree2;

	tree2.draw = RenderTree;
	tree2.transform = TransformTree2;
	tree2.child = NULL;
	tree2.sibling = &tree3;

	tree3.draw = RenderTree;
	tree3.transform = TransformTree3;
	tree3.child = NULL;
	tree3.sibling = NULL;

}

void init(void)
{
	// Define material properties 
	GLfloat mat_spec[] = { 3000.0, 3000.0, 3000.0, 3000.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 1.0, 0.0, 0.0 };

	// Set light properties ... 
	GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
	// and create two lights at two positions 
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_posl[] = { -1.0, -1.0, 1.0, 0.0 };

	// Set clear (background) color 
	glClearColor(0.0, 0.0, 0.0, 0.0);

	// Set shading model to use 
	glShadeModel(GL_SMOOTH);

	// Set material properties, as defined above 
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);

	// Finish setting up the two lights (position, 
	// and component values (specular and diffuse)) 
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_posl);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

	// Enable lighting 
	glEnable(GL_LIGHTING);
	// Act�vate (enable) individual lights 
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	// Enable depth testing (for hidden surface removal) 
	glEnable(GL_DEPTH_TEST);

	/*root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = NULL;
	root.sibling = NULL;*/

	CreateShape();
}

void display(void) {
	// Clear the buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Get model - from library 
	//glutSolidTeapot(0.80);
	glPushMatrix();
	//glRotatef(7.0, 0.0, 1.0, 0.0);
	traverse(&root);
	glPopMatrix();
	glFlush();
}

void reshape(int w, int h) {
	// Set the viewport size, based on function input 
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size 
	glMatrixMode(GL_PROJECTION);
	// first set as identity 
	glLoadIdentity();
	// then set perspective projection parameters based 
	// on aspect ratio 
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 50.0);
	// Set the model view matrix to identity 
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// Set the "look at" point 
	//Ojo , objetivo, 
	camX = 0.0;
	camY = 9.0;
	gluLookAt(camX, camY, 40.0, 0.0, 5, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key)
	{
		// Use "Esc" key to exit
	case 27:
		exit(0);
		break;
	case 'a':
		camX += 1.0;
		break;
	case 'A':
		camX -= 1.0;
		break;
	case 's':
		camY += 1.0;
		break;
	case 'S':
		camY -= 1.0;
		break;
	}
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(camX, camY, 40.0, 0.0, 5, 0.0, 0.0, 1.0, 0.0);
	glutPostRedisplay();
}


int main(int argc, char** argv) {
	// GLUT INITIALIZATION 
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Robot Humanoid");

	// Additional initalization 
	init();

	// Register callback functions 
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(display);

	// Do main loop 
	glutMainLoop();

	// Exit
	return 0;
}

