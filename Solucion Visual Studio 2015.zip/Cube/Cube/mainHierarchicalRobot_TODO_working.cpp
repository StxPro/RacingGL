#include <windows.h>
#include <math.h>
#include <GL/gl.h>
//#include <GL/glut.h>
#include <iostream>
#include <ctime> 
#include <array>
#include <vector>
#include "glut.h"

typedef struct treenode
{
	// Transform
	void (*transform)();
	// Render
	void (*draw)();
	// Child
	struct treenode *child;
	// Sibling
	struct treenode *sibling;
} treenode;

// Nodes for Robot
treenode base;
treenode lowerArm;
treenode upperArm;
treenode root;
treenode root2;
treenode root3;
treenode root4;

// Global variables for each of the 4 angles
static float angle1 = 0.0;
static float angle2 = 0.0;
static float angle3 = 0.0;

// Set the increment
static float angleInc = 3.0;

// NOTES:
// These are dimensions used for creating the robot
float baseHeight = 5.0;
float linkLength = 3.0;
float linkWidth = 1.0;

void init(void)
{
    // Set clear (background) color
	glClearColor(0.3, 0.32, 0.354, 0.0);

   // Set light properties...
   GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat light_position0[] = { 1.0, 1.0, 1.0, 0.0 };
   GLfloat light_position1[] = { -1.0, 1.0, 0.5, 0.0 };

   // Finish setting up the two lights (position, and component values (specular and diffuse))
   glLightfv(GL_LIGHT0, GL_POSITION, light_position0);
   glLightfv(GL_LIGHT0, GL_AMBIENT_AND_DIFFUSE, white_light);
   glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

   glLightfv(GL_LIGHT1, GL_POSITION, light_position1);
   glLightfv(GL_LIGHT1, GL_AMBIENT_AND_DIFFUSE, white_light);
   glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

   // Define material properties
   GLfloat mat_specular[] = { 0.8, 0.9, 1.0, 1.0 };
   GLfloat mat_shininess[] = { 30.0 };
   GLfloat mat_surface[] = { 0.2, 0.2, 0.9, 1.0 };

   // Set material properties, as defined above
   glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
   glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
   glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surface);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surface);

   // Set shading model to use
   glShadeModel (GL_SMOOTH);

   // Enable lighting
   glEnable(GL_LIGHTING);
   // Activate (enable) lights
   glEnable(GL_LIGHT0);
   glEnable(GL_LIGHT1);

   // Enable depth testing (for hidden surface removal)
   glEnable(GL_DEPTH_TEST);

}

void DrawBase(void)
{
	// TO DO - Draw (e.g. using glutSolidCube) the base
	glPushMatrix();
	glTranslated(0.0, baseHeight/2.0, 0.0);
	glScaled(linkWidth, baseHeight, linkWidth);
	glutSolidCube(1.0);
	glPopMatrix();
}

void DrawArm_Lower( void)
{
	// TO DO - Draw (e.g. using glutSolidCube) the lower arm
	glPushMatrix();
	glTranslated(linkLength/2.0, 0.0, 0.0);
	glScaled(linkLength, linkWidth, linkWidth);
	glutSolidCube(1.0);
	glPopMatrix();
}

void DrawArm_Upper( void )
{
	// TO DO - Draw (e.g. using glutSolidCube) the upper arm

	//Exactly the same as LOWER ARM
}

void TransformBase()
{
	glRotatef(angle1, 0.0, 1.0, 0.0);
}

void TransformLowerArm()
{
	glTranslated(0.0, baseHeight, 0.0);
	glRotated(angle2, 0.0, 0.0, 1.0);
}

void TransformUpperArm()
{
	glTranslated(linkLength, 0.0, 0.0);
	glRotated(angle3, 0.0, 0.0, 1.0);
}

void TransformR1()
{
	glTranslated(-4.0, 0.0, 0.0);
}

void TransformR2()
{
	glTranslated(4.0, 0.0, 0.0);
}

void TransformR3()
{
	glTranslated(4.0, 0.0, -4.0);
}

void TransformR4()
{
	glTranslated(-4.0, 0.0, -4.0);
}

void DisplayNothing()
{
}

/*
void robot(void)
{
	// Initial Push-Pop, so that each time display is called, the same image is drawn
    glPushMatrix();

    // Draw the base
	// NOTE: The rotation applied to the base will be applied to all subsequent linkages
	//		 Therefore, no push-pop pair is necessary
    // -----------------------------
	// Step 1: Apply transformation
	glRotatef(angle1, 0.0, 1.0, 0.0);

	// Step 2: Draw Figure
	DrawBase();

    // Draw the next link (lower arm)
    // -----------------------------
	// Step 1: Apply transformation
	// Move (translate) the current transformation to the top of the base
	glTranslated(0.0, baseHeight, 0.0);
	glRotated(angle2, 0.0, 0.0, 1.0);

	// Step 2: Draw Figure
	DrawArm_Lower();
    
    // Draw the last link (upper arm)
    // -----------------------------
	// Step 1: Apply transformation
    // To draw, first, translate to the end of the link
    
	glTranslated(linkLength, 0.0, 0.0);
	glRotated(angle3, 0.0, 0.0, 1.0);
    
    // Step 2: Draw Figure
	//DrawArm_Upper();
	DrawArm_Lower();

    glPopMatrix();

}
*/

void CreateRobot()
{
	// root
	root.transform = TransformR1;
	root.draw = DisplayNothing;
	root.child = &base;
	root.sibling = &root2;

	root2.transform = TransformR2;
	root2.draw = DisplayNothing;
	root2.child = &base;
	root2.sibling = &root3;

	root3.transform = TransformR3;
	root3.draw = DisplayNothing;
	root3.child = &base;
	root3.sibling = &root4;

	root4.transform = TransformR4;
	root4.draw = DisplayNothing;
	root4.child = &base;
	root4.sibling = NULL;

	//base
	base.transform = TransformBase;
	base.draw = DrawBase;
	base.child = &lowerArm;
	base.sibling = NULL;

	//lowerArm
	lowerArm.transform = TransformLowerArm;
	lowerArm.draw = DrawArm_Lower;
	lowerArm.child = &upperArm;
	lowerArm.sibling = NULL;

	//upperArm
	upperArm.transform = TransformUpperArm;
	upperArm.draw = DrawArm_Lower;	// same as lower arm
	upperArm.child = NULL;
	upperArm.sibling = NULL;
}
 
void traverse( treenode *node )
{
	glPushMatrix();
	// Transform
	node->transform();

	// Draw
	node->draw();

	// Child
	if ( node->child != NULL )
		traverse( node->child );

	glPopMatrix();

	// Sibling
	if ( node->sibling != NULL )
		traverse( node->sibling );

}

void display(void)
{
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glPushMatrix();

	traverse( &root );

	glPopMatrix();
	
	/*
	glPushMatrix();
	glTranslated(-4.0, 0.0, 0.0);
    robot();
	glPopMatrix();

	glPushMatrix();
	glTranslated(4.0, 0.0, 0.0);
    robot();
	glPopMatrix();

	glPushMatrix();
	glTranslated(4.0, 0.0, -4.0);
    robot();
	glPopMatrix();

	glPushMatrix();
	glTranslated(-4.0, 0.0, -4.0);
    robot();
	glPopMatrix();
	*/

	glutSwapBuffers();
}

void reshape(int w, int h)
{
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 40.0);
	//glOrtho(-8.0,8.0,-8.0,8.0, 1.0, 40.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 7.0, 12.0, 0.0, 5.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
		case 'a':
            angle1-=angleInc;
            break;
		case 'A':
			angle1+=angleInc;
			break;
        case 's':
            angle2-=angleInc;
            break;
		case 'S':
			angle2+=angleInc;
			break;
		case 'd':
            angle3-=angleInc;
            break;
		case 'D':
            angle3+=angleInc;
			break;
		case 0x1B:
		case 'q':
		case 'Q':
			exit(0);
			break;
		default:
			break;
	}
}

int main (int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Heirarchical Model - '2D' Robot Arm Example");
	init();

	// Create the robot with nodes
	CreateRobot();

	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(display);

	glutMainLoop();
	return 0;
}
