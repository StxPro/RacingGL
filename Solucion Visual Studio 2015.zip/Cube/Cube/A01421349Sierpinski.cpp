#include <windows.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <iostream>
#include <ctime> 
//#include "glut.h" 

//Variable para el primer punto aleatorio dentro del triangulo
float puntoMiddle[3] = { 0.5,0.5,0.0 };
//Funcion para obtener un punto parametrizado de acuerdo a dos puntos
float l(float, int, float[], float[]);
//Variables de los vertices
float v1[3] = { 0.0,0.0,0.0 };
float v2[3] = { (1.7f/2.0f),1.7f,0.0 };
float v3[3] = { 1.7f,0.0,0.0 };
//Variable auxiliar para poner cada punto dentro del triangulo
float aux[3] = {0.0,0.0,0.0};
//Variable para contar los clicks del mouse
int c = 0;


void init(void)
{
	GLfloat mat_spec[] = { 3000.0, 3000.0, 3000.0, 3000.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 1.0, 0.0, 0.0 };
	GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_pos1[] = { -1.0, -1.0, 1.0, 0.0 };

	glClearColor(0.0, 0.0, 0.0, 0.0);

	glShadeModel(GL_SMOOTH);

	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);

	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_pos1);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

	glEnable(GL_DEPTH_TEST);
	glPointSize(1);
}

// Napoleon Cortes Mata A01421349
void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	glColor3f(0.0, 0.0, 1.0);

	//Dibujar los vertices

	glBegin(GL_LINES);
	//Color blanco para los vertices
	glColor3f(1, 1, 1);
	//Al ya haber dado dos clicks se puede dibujar el primer vertice
	if (c > 1) {
		glVertex3fv(v1);
		glVertex3fv(v2);
	}
	//Al tercer click ya se pueden dibujar los demas vertices
	if (c > 2) {
		glVertex3fv(v1);
		glVertex3fv(v3);
		glVertex3fv(v2);
		glVertex3fv(v3);
	}

	glEnd();
	
	glBegin(GL_POINTS);


	glColor3f(0, 1, 0);
	//Al tercer click ya se puede empezar con los siguientes pasos del algoritmo
	if (c > 2) {
		glColor3f(1, 1, 1);
		//Obtener el primer punto dentro del triangulo de forma aleatoria
		//Se obtiene en base a la funcion de representacion parametrica de una linea
		//Primero obtengo un punto aleatorio entre los vertices 1 y 2
		//Luego obtengo un punto entre el punto obtenido anterior y el vertice 3
		float nrand = ((rand() % 11)/10.0);
		//std::cout << nrand << std::endl;
		puntoMiddle[0] = l(nrand, 0, v1, v2);		
		nrand = ((rand() % 11) / 10.0);
		//std::cout << nrand << std::endl;
		puntoMiddle[1] = l(nrand, 1, v1, v2);

		nrand = ((rand() % 11) / 10.0);
		float ax = l(nrand, 0, puntoMiddle, v3);
		nrand = ((rand() % 11) / 10.0);
		float ay = l(nrand, 1, puntoMiddle, v3);
		puntoMiddle[0] = ax;
		puntoMiddle[1] = ay;

		glVertex3fv(puntoMiddle);

		//Ya con el primer punto se empiezan a obtener los demas
		for (size_t i = 0; i < 30000; i++)
		{
			//Se elige aleatoriamente el vertice a calcular la mitad de la distancia (t=0.5)
			switch ((rand() % 3))
			{
			case 0:
				glColor3f(1, 0, 0);
				//Se calcula el valor de x y y para el punto en una variable auxiliar y se dibuja
				aux[0] = l(0.5, 0, puntoMiddle, v1);
				aux[1] = l(0.5, 1, puntoMiddle, v1);
				glVertex3fv(aux);
				//Se actualiza la variable que se usa para calcular el siguiente punto
				puntoMiddle[0] = aux[0];
				puntoMiddle[1] = aux[1];
				puntoMiddle[2] = aux[2];
				break;
			case 1:
				glColor3f(0, 1, 0);
				aux[0] = l(0.5, 0, puntoMiddle, v2);
				aux[1] = l(0.5, 1, puntoMiddle, v2);
				glVertex3fv(aux);
				puntoMiddle[0] = aux[0];
				puntoMiddle[1] = aux[1];
				puntoMiddle[2] = aux[2];
				break;
			case 2:
				glColor3f(0, 0, 1);
				aux[0] = l(0.5, 0, puntoMiddle, v3);
				aux[1] = l(0.5, 1, puntoMiddle, v3);
				glVertex3fv(aux);
				puntoMiddle[0] = aux[0];
				puntoMiddle[1] = aux[1];
				puntoMiddle[2] = aux[2];
				break;
			default:
				break;
			}
		}
	}
	
	
	glEnd();


	
	
	glFlush();
}

void reshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 20.0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//Se modificaron los valores para poder visualizar de mejor forma en 2D
	//Tambien se modifico para que el eje empieze en (0,0) a partir de la ezquina inferior izquierda
	gluLookAt(0.0, 0.0, 5.0, 0.85, 0.85, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	case 27:
		exit(0);
		break;
	case 'a':
		//srand((unsigned)time(0));
		//std::cout << (rand() % 3) << std::endl;

		//exit(0);
		break;
	case 'd':
		//std::cout << (rand() % 11)/10.0 << std::endl;
		//glutPostRedisplay();
		break;
	}
}

//Funcion para encontrar un punto de acuerdo a la representacion parametrizada de una linea
//Como entrada recibe t - que es un valor de 0 a 1 y 0.5 representa la mitad de la linea,
//i - representa el eje a devolver 0 para x, 1 para y, y 2 para z
//p1 y p2 son los puntos extremos de la linea
float l(float t, int i, float p1[], float p2[]) {
	//Se obtiene v con la diferencia de los puntos extremos
	float v[3] = { p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2] };
	//Se obtiene vt multiplicando v y t
	float vt[3] = { v[0] * t, v[1] * t, v[2] * t };
	//Se obtienen las coordenadas finales sumando el primer punto extremo de la linea y vt
	float r[3] = { p1[0] + vt[0], p1[1] + vt[1], p1[2] + vt[2] };
	return r[i];
}

void mouse(int button, int state, int x, int y) {
	//572 -> 1

	//std::cout << (float)(x-6)/600*1.788 << std::endl;
	//std::cout << (float)(585 - y) / 600 * 1.85 << std::endl;

	//Se obtienen los valores iniciales de los vertices de acuerdo a las pociciones de los clicks
	//Para el eje y se tiene que invertir ya que el mouse detecta positivo de arriba para abajo
	//Se hicieron algunos calculos a prueba y error para mapear la posicion del mouse con las coordenadas de los vectores
	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP && c < 3) {
		switch (c)
		{
			//Primer click
		case 0:
			srand(time(NULL));
			v1[0] = (float)(x - 6) / 600 * 1.788;
			v1[1] = (float)(585 - y) / 600 * 1.85;
			break;
			//Segundo click
		case 1:
			v2[0] = (float)(x - 6) / 600 * 1.788;
			v2[1] = (float)(585 - y) / 600 * 1.85;
			break;
			//Tercer click
		case 2:
			v3[0] = (float)(x - 6) / 600 * 1.788;
			v3[1] = (float)(585 - y) / 600 * 1.85;
			break;
		default:
			break;
		}
		//Aumento en la variable contadora de clicks
		c++;
	}
	//Actualizar los dibujos
	glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(600, 600);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Sierpinski");

	init();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);

	glutMainLoop();

	return 0;
}



