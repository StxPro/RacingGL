#include <windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

float X1, Y1, Z1, r1;
float X2, Y2, Z2, r2;

float VX1, VY1, VZ1;
float VX2, VY2, VZ2;

float AX1, AY1, AZ1;
float AX2, AY2, AZ2;

float deltaT;
float deltaT2;
void SetCollisionColor()
{
	// Define material properties
	GLfloat mat_spec[] = { 30.0, 30.0, 30.0, 1.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 0.1, 0.1, 0.0 };

	// Set material properties, as defined above
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf);
}

void SetNormalColor()
{
	// Define material properties
	GLfloat mat_spec[] = { 30.0, 30.0, 30.0, 1.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 1.0, 0.1, 0.0 };

	// Set material properties, as defined above
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf);
}

void init(void)
{
	// Initialize bounding shapes
	X1 = 4.0f;
	Y1 = 0.0f;
	Z1 = 0.0f;
	r1 = 1.0f;

	X2 = -4.0f;
	Y2 = 0.0f;
	Z2 = 0.0f;
	r2 = 1.0f;

	VX1 = 0.0f;
	VY1 = 0.0f;
	VZ1 = 0.0f;

	VX2 = 0.0f;
	VY2 = 0.0f;
	VZ2 = 0.0f;

	AX1 = 0.0f;
	AY1 = 0.0f;
	AZ1 = 0.0f;

	AX2 = 0.0f;
	AY2 = 0.0f;// -9.81f;
	AZ2 = 0.0f;

	deltaT = 1.0f / 1000.0f;
	deltaT2 = 1.0f / 1000.0f;
	// Set light properties...
	GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
	// and create two lights at two positions
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_pos1[] = { -1.0, -1.0, 1.0, 0.0 };

	// Set clear (background) color
	glClearColor(0.0, 0.0, 0.0, 0.0);

	// Set shading model to use
	glShadeModel(GL_SMOOTH);

	// Finish setting up the two lights (position, and component values (specular and diffuse))
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_pos1);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

	// Enable lighting
	glEnable(GL_LIGHTING);
	// Activate (enable) lights
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	// Enable depth testing (for hidden surface removal)
	glEnable(GL_DEPTH_TEST);
}

void display(void)
{
	// Clear the buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// PHYSICS
	//float tempVY, tempY;
	//tempVY = VY1 + AY1*deltaT;
	float X2prev = X2;
	float X1prev = X1;

	VX2 += AX2*deltaT;
	X2 += VX2*deltaT;

	VX1 += AX1*deltaT2;
	X1 += VX1*deltaT2;

	// check for collisions
	float distance = sqrt((X2 - X1)*(X2 - X1) + (Y2 - Y1)*(Y2 - Y1) + (Z2 - Z1)*(Z2 - Z1));

	if (distance <= (r1 + r2))
	{
		// Collisions TRUE
		SetCollisionColor();
		

		// If we only want to stop the object:
		//VX2 = 0.0;
		//X2 = X2prev;
		AX1 = -AX2;
		// If we want object to bounce
		//r = 2 a .n +  a
		float nx = 1.0f;
		float ny = 0.0f;
		float nz = 0.0f;
		float magV = sqrt(VX2*VX2 + VY2*VY2 + VZ2*VZ2);
		//////////////////////////////////////
		float nx1 = 1.0f;
		float ny1 = 0.0f;
		float nz1 = 0.0f;
		float magV1 = sqrt(VX1*VX1 + VY1*VY1 + VZ1*VZ1);
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////

		// Normalize
		float nvx = VX2 / magV;
		float nvy = VY2 / magV;
		float nvz = VZ2 / magV;

		float rx, ry, rz;

		/////////// r = 2 a .n * n +  a
		float nvx1 = VX1 / magV1;
		float nvy1 = VY1 / magV1;
		float nvz1 = VZ1 / magV1;

		float rx1, ry1, rz1;
		/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		float ndota = -(nx*nvx + ny*nvy + nz*nvz)*2.0f;
		rx = ndota*nx + nvx;
		ry = ndota*ny + nvy;
		rz = ndota*nz + nvz;

		rx = rx*magV;
		ry = ry*magV;
		rz = rz*magV;

		VX2 = rx;
		X2 = rx*deltaT + X2prev;
		////////////////////////77
		float ndota1 = -(nx1*nvx1 + ny1*nvy1 + nz1*nvz1)*2.0f;
		rx1 = ndota1*nx1 + nvx1;
		ry1 = ndota1*ny1 + nvy1;
		rz1 = ndota1*nz1 + nvz1;

		rx1 = rx1*magV1;
		ry1 = ry1*magV1;
		rz1 = rz1*magV1;

		VX1 = rx1;
		X1 =  rx1*deltaT2 + X1prev;
		/////////////////////////////////////////////////////////////////////////////////////////////////
		
	}
	// Collisions FALSE
	else 
	{
		SetNormalColor();
	}
	// Shape 1
	glPushMatrix();
	glTranslatef(X1, Y1, Z1);
	glutWireSphere(r1, 10, 10);
	glutSolidTeapot(r1*0.8);
	glPopMatrix();

	// Shape 2
	glPushMatrix();
	glTranslatef(X2, Y2, Z2);
	glutWireSphere(r2, 10, 10);
	glutSolidTeapot(r2*0.8);
	glPopMatrix();

	glFlush();

	//AY2 = 0.0;
}

void reshape(int w, int h)
{
	// Set the viewport size, based on function input
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size
	glMatrixMode(GL_PROJECTION);
	// first set as identity
	glLoadIdentity();
	// then set perspective projection parameters based on aspect ratio
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 60.0);

	// Set the model view matrix to identity
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Set the "look at" point
	gluLookAt(6.0, 5.0, 50.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 's':
		AX2 -= 10.0;
		AX1 += 10.0;
		glutPostRedisplay();
		break;
	case 'w':
		AX2 += 10.0;
		AX1 -= 10.0;
		glutPostRedisplay();
		break;
		// Use "Esc" key to exit
	case 27:
		exit(0);
		break;
	}
}

int main(int argc, char** argv)
{
	// GLUT INITIALIZATION
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1500, 900);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("OpenGL Teapot");

	// Additional initalization
	init();

	// Register callback functions
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(display);

	// Do main loop
	glutMainLoop();

	// Exit
	return 0;
}
