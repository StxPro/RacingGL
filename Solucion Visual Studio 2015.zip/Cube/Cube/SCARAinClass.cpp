#include <windows.h> 
#include <GL/gl.h> 
#include "glut.h"  

typedef	struct node {
	void(*transform)();
	void(*draw)();
	node *child;
	node *sibling;
}node;


void traverse(node *root) {
	glPushMatrix();

	root->transform();
	root->draw();

	if (root->child != NULL)
	{
		traverse(root->child);
	}

	if (root->sibling != NULL)
		traverse(root->sibling);
}

node root;
float angle1;

node child1;
float angle2;

void RenderRoot() {
	glPushMatrix();
	glTranslatef(0.0, 2.5, 0.0);
	glScalef(1.0, 5.0, 1.0);
	glutSolidCube(1.0);
	glPopMatrix();
}

void TransformRoot() {
	glRotatef(angle1, 0.0, 1.0, 0.0);
}

void RenderChild1() {

}

void TransforChild1() {

}

void CreateShape() {
	root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = NULL;
	root.sibling = NULL;

	child1.draw = RenderChild1;
	child1.transform = TransforChild1;
	child1.child = NULL;
	child1.sibling = NULL;
}

void init(void)
{
	// Define material properties 
	GLfloat mat_spec[] = { 3000.0, 3000.0, 3000.0, 3000.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 1.0, 0.0, 0.0 };

	// Set light properties ... 
	GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
	// and create two lights at two positions 
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_posl[] = { -1.0, -1.0, 1.0, 0.0 };

	// Set clear (background) color 
	glClearColor(0.0, 0.0, 0.0, 0.0);

	// Set shading model to use 
	glShadeModel(GL_SMOOTH);

	// Set material properties, as defined above 
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);

	// Finish setting up the two lights (position, 
	// and component values (specular and diffuse)) 
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_posl);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

	// Enable lighting 
	glEnable(GL_LIGHTING);
	// Act�vate (enable) individual lights 
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	// Enable depth testing (for hidden surface removal) 
	glEnable(GL_DEPTH_TEST);

	/*root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = NULL;
	root.sibling = NULL;*/

	CreateShape();
}

void display(void) {
	// Clear the buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Get model - from library 
	//glutSolidTeapot(0.80);
	traverse(&root);
	glFlush();
}

void reshape(int w, int h) {
	// Set the viewport size, based on function input 
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size 
	glMatrixMode(GL_PROJECTION);
	// first set as identity 
	glLoadIdentity();
	// then set perspective projection parameters based 
	// on aspect ratio 
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 50.0);
	// Set the model view matrix to identity 
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// Set the "look at" point 
	//Ojo , objetivo, 
	gluLookAt(10.0, 5.0, 20.0, 0.0, 2.5, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key)
	{
		// Use "Esc" key to exit
	case 27:
		exit(0);
		break;

	case 'a':
		angle1 += 4.0;
		break;
	}

	glutPostRedisplay();
}


int main(int argc, char** argv) {
	// GLUT INITIALIZATION 
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("SCARA in class");

	// Additional initalization 
	init();

	// Register callback functions 
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(display);

	// Do main loop 
	glutMainLoop();

	// Exit
	return 0;
}

