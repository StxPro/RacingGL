#include <windows.h>
#include <math.h>
#include <GL/gl.h>
//#include <GL/glut.h>
#include <iostream>
#include <ctime> 
#include <array>
#include <vector>
#include "glut.h"
#include <gl/GLU.h>

static bool white = false;
static bool red = false;
static bool green = false;
static bool blue = false;

typedef	struct node {
	void(*transform)();
	void(*draw)();
	struct node *child;
	struct node *sibling;
}node;

float rota;

float iint = 1.0;

void traverse(node *root) {
	glPushMatrix();

	root->transform();
	root->draw();

	if (root->child != NULL)
	{
		traverse(root->child);
	}

	glPopMatrix();

	if (root->sibling != NULL)
		traverse(root->sibling);
}

void drawCylinder(GLdouble baseRadius,
	GLdouble topRadius,
	GLdouble height,
	GLint slices,
	GLint stacks)
{
	GLUquadricObj *qobj;
	qobj = gluNewQuadric();
	gluQuadricDrawStyle(qobj, GLU_FILL);
	gluCylinder(qobj, baseRadius, topRadius, height,
		slices, stacks);
}


void CreateShape() {

}

void init(void)
{

	// Set light properties ... 
	GLfloat white_light[] = { iint, iint, iint, 1.0 };
	GLfloat red_light[] = { iint, 0.0, 0.0, 1.0 };
	GLfloat blue_light[] = { 0.0, 0.0, iint, 1.0 };
	GLfloat green_light[] = { 0.0, iint, 0.0, 1.0 };

	// and create two lights at two positions 
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_posl[] = { -1.0, -1.0, 1.0, 0.0 };
	GLfloat light_pos2[] = { -1.0, 1.0, 1.0, 0.0 };
	GLfloat light_pos3[] = { 1.0, -1.0, 1.0, 0.0 };




	// Set clear (background) color 
	glClearColor(0.2, 0.2, 0.2, 0.0);

	// Set shading model to use 
	glShadeModel(GL_SMOOTH);

	// Finish setting up the two lights (position, 
	// and component values (specular and diffuse)) 
	// Luz ambiente difuso especular posicion
	// Material 
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_posl);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, red_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, red_light);

	glLightfv(GL_LIGHT2, GL_POSITION, light_pos2);
	glLightfv(GL_LIGHT2, GL_DIFFUSE, green_light);
	glLightfv(GL_LIGHT2, GL_SPECULAR, green_light);

	glLightfv(GL_LIGHT3, GL_POSITION, light_pos3);
	glLightfv(GL_LIGHT3, GL_DIFFUSE, blue_light);
	glLightfv(GL_LIGHT3, GL_SPECULAR, blue_light);

	// Enable lighting 
	glEnable(GL_LIGHTING);
	// Act�vate (enable) individual lights 
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHT2);
	glEnable(GL_LIGHT3);

	// Enable depth testing (for hidden surface removal) 
	glEnable(GL_DEPTH_TEST);

	/*root.draw = RenderRoot;
	root.transform = TransformRoot;
	root.child = NULL;
	root.sibling = NULL;*/

	CreateShape();
}

void display(void) {
	// Clear the buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Get model - from library 
	//glutSolidTeapot(0.80);
	// Define material properties 
	glPushMatrix();

	glPushMatrix();
	glTranslatef(-6.5, 9.0, 0.0);
	glRotatef(rota, 0.0, 1.0, 0.0);
	glPushMatrix();
	GLfloat mat_spec[] = { 0.5, 0.5, 0.5, 1.0 };
	GLfloat mat_shiny[] = { 50.0 };
	GLfloat mat_surf[] = { 1.0, 0.1, 0.1, 1.0 };

	// Set material properties, as defined above 
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf);

	//glTranslatef(-6.5, 9.0, 0.0);

	glRotatef(45, 0.0, 0.0, 1.0);
	glRotatef(rota, 1.0, 0.0, 0.0);
	glScalef(2.0, 2.0, 2.0);
	glRotatef(rota, 0.0, 1.0, 0.0);
	glutSolidCube(1.0);
	glPopMatrix();
	glPopMatrix();
	glPushMatrix();
	GLfloat mat_spec2[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_shiny2[] = { 500.0 };
	GLfloat mat_surf2[] = { 1.0, 1.0, 1.0, 1.0 };

	// Set material properties, as defined above 
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec2);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny2);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf2);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf2);
	glTranslatef(0.0, 5.0, 0.0);
	glRotatef(rota, 0.0, 1.0, 0.0);
	glutSolidSphere(1.0, 20, 20);
	glPopMatrix();
	glPushMatrix();
	GLfloat mat_spec3[] = { 0.0, 0.0, 0.0, 1.0 };
	GLfloat mat_shiny3[] = { 1.0 };
	GLfloat mat_surf3[] = { 165.0 / 255.0, 110.0 / 255.0, 0.0 / 255.0, 1.0 };

	// Set material properties, as defined above 
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec3);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny3);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf3);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf3);
	glTranslatef(7.0, 0.0, 0.0);
	glRotatef(rota, 0.0, 1.0, 0.0);
	glRotatef(-90, 1.0, 0.0, 0.0);
	drawCylinder(1.0, 1.0, 3.0, 20.0, 20.0);
	//glutSolidSphere(1.0, 20, 20);
	glPopMatrix();
	glPopMatrix();
	glFlush();
}

void reshape(int w, int h) {
	// Set the viewport size, based on function input 
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size 
	glMatrixMode(GL_PROJECTION);
	// first set as identity 
	glLoadIdentity();
	// then set perspective projection parameters based 
	// on aspect ratio 
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 50.0);
	// Set the model view matrix to identity 
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// Set the "look at" point 
	//Ojo , objetivo, 
	gluLookAt(0.0, 9.0, 40.0, 0.0, 5, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key)
	{
		// Use "Esc" key to exit
	case 27:
		exit(0);
		break;
	case 'q':
		if (white) {
			white = !white;
			glEnable(GL_LIGHT0);
		}
		else {
			white = !white;
			glDisable(GL_LIGHT0);
		}
		break;
	case 'w':
		if (red) {
			red = !red;
			glEnable(GL_LIGHT1);
		}
		else {
			red = !red;
			glDisable(GL_LIGHT1);
		}
		break;
	case 'e':
		if (green) {
			green = !green;
			glEnable(GL_LIGHT2);
		}
		else {
			green = !green;
			glDisable(GL_LIGHT2);
		}
		break;
	case 'r':
		if (blue) {
			blue = !blue;
			glEnable(GL_LIGHT3);
		}
		else {
			blue = !blue;
			glDisable(GL_LIGHT3);
		}
		break;
	case 'z':
		iint -= 0.1;
		break;
	case 'x':
		iint += 0.1;
		break;
	case 'a':
		rota++;
		break;
	case 's':
		rota--;
		break;
	}

	//glMatrixMode(GL_MODELVIEW);
	//glLoadIdentity();
	glutPostRedisplay();
}


int main(int argc, char** argv) {
	// GLUT INITIALIZATION 
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("mainlightsA01421349");

	// Additional initalization 
	init();

	// Register callback functions 
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(display);

	// Do main loop 
	glutMainLoop();

	// Exit
	return 0;
}

