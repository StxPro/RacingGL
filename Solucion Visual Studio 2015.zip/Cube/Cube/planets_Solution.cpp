#include <windows.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <iostream>
#include <ctime> 
//#include "glut.h" 

// Set the variables for all years
static float year1 = 0.0f;
static float year2 = 0.0f;
static float year3 = 0.0f;
static float year4 = 0.0f;
static float year5 = 0.0f;
static float year6 = 0.0f;
static float year7 = 0.0f;
static float year8 = 0.0f;

// Set the variables for all days
static float day1 = 0.0f;
static float day2 = 0.0f;
static float day3 = 0.0f;
static float day4 = 0.0f;
static float day5 = 0.0f;
static float day6 = 0.0f;
static float day7 = 0.0f;
static float day8 = 0.0f;

// Set the increment for the years
static float yearinc1 = 1.5f;
static float yearinc2 = 1.0f;
static float yearinc3 = 0.5f;
static float yearinc4 = 0.3f;
static float yearinc5 = 0.08f;
static float yearinc6 = 0.06f;
static float yearinc7 = 0.03f;
static float yearinc8 = 0.01f;

// Set the increment for the days
// To simplify, we will set the duration of all days the same
// We can make an individual variable for each
static float dayinc = 0.25f;

// Flag for automatic rotation
static bool doAuto = false;

void init(void)
{
    // Set clear (background) color
	glClearColor(0.0, 0.0, 0.0, 0.0);

   // Set light properties...
   GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat light_position0[] = { 0.0, 0.0, 0.0, 1.0 };

   // Finish setting up the two lights (position, and component values (specular and diffuse))
   glLightfv(GL_LIGHT0, GL_POSITION, light_position0);
   glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
   glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

   // Set shading model to use
   glShadeModel (GL_SMOOTH);

   // Enable lighting
   glEnable(GL_LIGHTING);
   // Activate (enable) lights
   glEnable(GL_LIGHT0);
   // Enable depth testing (for hidden surface removal)
   glEnable(GL_DEPTH_TEST);

}

void singlePlanet( float yearPlanet, float dayPlanet, float distancePlanet, float sizePlanet )
{
    glPushMatrix();
	glRotatef( (GLfloat) yearPlanet, 0.0, 1.0, 0.0);
	glTranslatef( (GLfloat) distancePlanet, 0.0, 0.0);
	glRotatef( (GLfloat) dayPlanet, 0.0, 1.0, 0.0);
	glutSolidSphere( (GLdouble) sizePlanet, 15, 12 );	// draw the planet itself
	//glutSolidTeapot( (GLdouble) sizePlanet );	// draw the planet itself
	glPopMatrix();
}

void singlePlanetWithMoon( float yearPlanet, float dayPlanet, float distancePlanet, float sizePlanet, float cycleMoon, float distanceMoon, float sizeMoon )
{
    // Move the planet
    glPushMatrix();
	glRotatef( (GLfloat) yearPlanet, 0.0, 1.0, 0.0);
	glTranslatef( (GLfloat) distancePlanet, 0.0, 0.0);

	// We don't want the moon rotating at the same rate as the day
	glPushMatrix();
	glRotatef( (GLfloat) dayPlanet, 0.0, 1.0, 0.0);
	glutSolidSphere( (GLdouble) sizePlanet, 15, 12 );	// draw the planet itself
	//glutSolidTeapot( (GLdouble) sizePlanet );	// draw the planet itself
	glPopMatrix();

	// We could also modify colors for moon here
    // Move the moon
    glRotatef( (GLfloat) cycleMoon, 0.0, 1.0, 0.0);
	glTranslatef( (GLfloat) distanceMoon, 0.0, 0.0);
	// We won't rotate the moon on it's axis, i.e. not modelling lunar day
	// But if we wanted to
    // glRotatef( (GLfloat) dayMoon, 0.0, 1.0, 0.0);
	glutSolidSphere( (GLdouble) sizeMoon, 15, 12 );	// draw the moon itself
	//glutSolidTeapot( (GLdouble) sizeMoon );	// draw the planet itself
	glPopMatrix();
}

void incrementYears( void )
{
    year1 = (GLfloat)(((GLint)(year1*100.f + yearinc1*100.f)) % 36000)/100.0f;
	year2 = (GLfloat)(((GLint)(year2*100.f + yearinc2*100.f)) % 36000)/100.0f;
	year3 = (GLfloat)(((GLint)(year3*100.f + yearinc3*100.f)) % 36000)/100.0f;
	year4 = (GLfloat)(((GLint)(year4*100.f + yearinc4*100.f)) % 36000)/100.0f;
	year5 = (GLfloat)(((GLint)(year5*100.f + yearinc5*100.f)) % 36000)/100.0f;
	year6 = (GLfloat)(((GLint)(year6*100.f + yearinc6*100.f)) % 36000)/100.0f;
	year7 = (GLfloat)(((GLint)(year7*100.f + yearinc7*100.f)) % 36000)/100.0f;
	year8 = (GLfloat)(((GLint)(year8*100.f + yearinc8*100.f)) % 36000)/100.0f;
}

void incrementDays( void )
{
	day1 =(GLfloat)(((GLint)(day1*100.f + dayinc*100.f)) % 36000)/100.0f;
	day2 =(GLfloat)(((GLint)(day2*100.f + dayinc*100.f)) % 36000)/100.0f;
	day3 =(GLfloat)(((GLint)(day3*100.f + dayinc*100.f)) % 36000)/100.0f;
	day4 =(GLfloat)(((GLint)(day4*100.f + dayinc*100.f)) % 36000)/100.0f;
	day5 =(GLfloat)(((GLint)(day5*100.f + dayinc*100.f)) % 36000)/100.0f;
	day6 =(GLfloat)(((GLint)(day6*100.f + dayinc*100.f)) % 36000)/100.0f;
	day7 =(GLfloat)(((GLint)(day7*100.f + dayinc*100.f)) % 36000)/100.0f;
	day8 =(GLfloat)(((GLint)(day8*100.f + dayinc*100.f)) % 36000)/100.0f;
}

void display(void)
{
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Define material properties
   GLfloat mat_specular[] = { 3.0, 3.0, 3.0, 3.0 };
   GLfloat mat_shininess[] = { 30.0 };
   GLfloat mat_surface[] = { 1.0, 1.0, 0.0, 0.0 };

   // Set material properties, as defined above
   glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
   glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
   glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surface);
   glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surface);

    // Draw the sun
	glPushMatrix();
	// Set a yellowish color
	mat_surface[0] = 255.0/255.0;
	mat_surface[1] = 234.0/255.0;
	mat_surface[2] = 60.0/255.0;
	mat_surface[3] = 0.0;
	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_surface);
	glutSolidSphere(1.0, 20, 16);	// draw sun
	glPopMatrix();

	// Draw first planet
	// ---------------------------------------------------------
	// Set the colors
	mat_surface[0] = 250.0/255.0;
	mat_surface[1] = 137.0/255.0;
	mat_surface[2] = 29.0/255.0;
	mat_surface[3] = 0.0;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_surface);
    // Call our function to draw planet
    // singlePlanet( yearPlanet, dayPlanet, distancePlanet, sizePlanet )
	singlePlanet( year1, day1, 1.5, 0.1 );

	// Draw second planet
	// ---------------------------------------------------------
	// Set the colors
	mat_surface[0] = 207.0/255.0;
	mat_surface[1] = 38.0/255.0;
	mat_surface[2] = 222.0/255.0;
	mat_surface[3] = 0.0;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_surface);
    // Call our function to draw planet
    // singlePlanet( yearPlanet, dayPlanet, distancePlanet, sizePlanet )
	singlePlanet( year2, day2, 2.2, 0.16 );

    // Draw third planet, with moon
    // ---------------------------------------------------------
    // Set the colors (for both)
    mat_surface[0] = 18.0/255.0;
	mat_surface[1] = 18.0/255.0;
	mat_surface[2] = 195.0/255.0;
	mat_surface[3] = 0.0;
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surface);
	// Call our function to draw planet with moon
	// singlePlanetWithMoon( yearPlanet, dayPlanet, distancePlanet, sizePlanet, cycleMoon, distanceMoon, sizeMoon )
	singlePlanetWithMoon( year3, day3, 3.0,  0.22, year3*4.0, 0.5, 0.09 );

    // Draw fourth planet, with moon
    // ---------------------------------------------------------
    // Set the colors (for both)
    mat_surface[0] = 255.0/255.0;
	mat_surface[1] = 141.0/255.0;
	mat_surface[2] = 18.0/255.0;
	mat_surface[3] = 0.0;
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surface);
	// Call our function to draw planet with moon
	// singlePlanetWithMoon( yearPlanet, dayPlanet, distancePlanet, sizePlanet, cycleMoon, distanceMoon, sizeMoon )
	singlePlanetWithMoon( year4, day4, 4.0,  0.19, year4*8.0, 0.5, 0.065 );

    // Draw fifth planet, with moon
    // ---------------------------------------------------------
    // Set the colors (for both)
    mat_surface[0] = 255.0/255.0;
	mat_surface[1] = 85.0/255.0;
	mat_surface[2] = 18.0/255.0;
	mat_surface[3] = 0.0;
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surface);
	// Call our function to draw planet with moon
	// singlePlanetWithMoon( yearPlanet, dayPlanet, distancePlanet, sizePlanet, cycleMoon, distanceMoon, sizeMoon )
	singlePlanetWithMoon( year5, day5, 5.5,  0.4, year5*4.0, 0.5, 0.085 );

	// Draw sixth planet
	// ---------------------------------------------------------
	// Set the colors
	mat_surface[0] = 150.0/255.0;
	mat_surface[1] = 137.0/255.0;
	mat_surface[2] = 29.0/255.0;
	mat_surface[3] = 0.0;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_surface);
    // Call our function to draw planet
    // singlePlanet( yearPlanet, dayPlanet, distancePlanet, sizePlanet )
	singlePlanet( year6, day6, 6.8, 0.35 );

	// Draw seventh planet
	// ---------------------------------------------------------
	// Set the colors
	mat_surface[0] = 50.0/255.0;
	mat_surface[1] = 137.0/255.0;
	mat_surface[2] = 229.0/255.0;
	mat_surface[3] = 0.0;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_surface);
    // Call our function to draw planet
    // singlePlanet( yearPlanet, dayPlanet, distancePlanet, sizePlanet )
	singlePlanet( year7, day7, 7.9, 0.3 );

	// Draw eighth planet
	// ---------------------------------------------------------
	// Set the colors
	mat_surface[0] = 207.0/255.0;
	mat_surface[1] = 38.0/255.0;
	mat_surface[2] = 222.0/255.0;
	mat_surface[3] = 0.0;
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_surface);
    // Call our function to draw planet
    // singlePlanet( yearPlanet, dayPlanet, distancePlanet, sizePlanet )
	singlePlanet( year8, day8, 9.2, 0.3 );

	glutSwapBuffers();

	// Code for automatic movement of planet
	// Increment the years and the days for all planets
	if (doAuto) {
	    incrementYears();
	    incrementDays();
	}
}

void reshape(int w, int h)
{
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 40.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 8.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
		case 'a':
		case 'A':
			// Toggle automatic movement of planet
			if (doAuto)
				doAuto = false;
			else
				doAuto = true;

		// Manual control of day and year movement
		case 'd':
		case 'D':
            incrementDays();
			glutPostRedisplay();
			break;
		case 'Y':
		case 'y':
			incrementYears();
			glutPostRedisplay();
			break;
		case 0x1B:
		case 'q':
		case 'Q':
			exit(0);
			break;
		default:
			break;
	}
}

void mouse(int btn, int state, int x, int y)
{
	if (state == GLUT_DOWN)
	{
		// Make the year move faster
		if (btn == GLUT_LEFT_BUTTON)
		{
			yearinc1 = yearinc1*2.0f;
			yearinc2 = yearinc2*2.0f;
			yearinc3 = yearinc3*2.0f;
			yearinc4 = yearinc4*2.0f;
			yearinc5 = yearinc5*2.0f;
			yearinc6 = yearinc6*2.0f;
			yearinc7 = yearinc7*2.0f;
			yearinc8 = yearinc8*2.0f;
		}
		// Make the day move faster
		else if (btn == GLUT_RIGHT_BUTTON)
			dayinc = dayinc*2.0;
		// If middle button, then reset increments
		else {
            yearinc1 = 1.5f;
            yearinc2 = 1.0f;
            yearinc3 = 0.5f;
            yearinc4 = 0.3f;
            yearinc5 = 0.08f;
            yearinc6 = 0.06f;
            yearinc7 = 0.03f;
            yearinc8 = 0.01f;
            dayinc = 0.25f;
		}

		glutPostRedisplay();
	}
}

int main (int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Solar System");
	init();

	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(display);

	glutMainLoop();
	return 0;
}
