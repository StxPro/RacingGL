#include <windows.h> // Comment this line if Linux 
#include <GL/gl.h> 
//#include <GL/glut.h> 
#include "glut.h" 

void init(void)
{
	// Define material properties
	/*GLfloat mat_spec[] = { 3000.0, 3000.0, 3000.0, 3000.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 1.0, 0.0, 0.0 };

	// Set light properties ...
	GLfloat other_light[]={1.0,1.0,1.0,1.0};
	// GLfloat white_light[] = { 0.0, 1.0, 0.0, 1.0 };
	// and create two lights at two positions
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_posl[] = { -1.0, -1.0, 1.0, 0.0 };

	// Set clear (background) color
	glClearColor(0.0, 0.0, 0.0, 0.0);

	// Set shading model to use
	glShadeModel(GL_SMOOTH);

	// Set material properties, as defined above
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);

	// Finish setting up the two lights (position,
	// and component values (specular and diffuse))
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, other_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, other_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_posl);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, other_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, other_light);

	// Enable lighting
	glEnable(GL_LIGHTING);
	// Act�vate (enable) individual lights
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	// Enable depth testing (for hidden surface removal)
	glEnable(GL_DEPTH_TEST);
	*/
	//change the size of the points
	glPointSize(10);
}


void display(void) {
	// Clear the buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Get model - from library

	glBegin(GL_TRIANGLE_STRIP);
	//Back face of the cube

	glColor3f(1.0, 0, 0);
	glVertex3f(0.5, -0.5, 0);
	glVertex3f(0.5, 0.5, 0);
	glVertex3f(-0.5, 0.5, 0);

	glColor3f(0, 1.0, 0);
	glVertex3f(-0.5, 0.5, 0);
	glVertex3f(-0.5, -0.5, 0);
	glVertex3f(0.5, -0.5, 0);

	//right face of the cube
	glColor3f(0.35, 0.21, 0.4);
	glVertex3f(0.5, -0.5, 0);
	glVertex3f(0.5, 0.5, 0);
	glVertex3f(0.5, -0.5, 1);

	glColor3f(0.35, 0.21, 0.4);
	glVertex3f(0.5, -0.5, 1);
	glVertex3f(0.5, 0.5, 1);
	glVertex3f(0.5, 0.5, 0);
	/*
	

	//Top face of the cube
	glColor3f(1, 0, 0);
	glVertex3f(0.5, 0.5, 0);
	glVertex3f(0.5, 0.5, 1);
	glVertex3f(-0.5, 0.5, 1);

	glColor3f(0, 1, 0);
	glVertex3f(-0.5, 0.5, 1);
	glVertex3f(0.5, 0.5, 0);
	glVertex3f(-0.5, 0.5, 0);

	//left face of the cube
	glColor3f(1, 0, 0);
	glVertex3f(-0.5, 0.5, 0);
	glVertex3f(-0.5, -0.5, 0);
	glVertex3f(-0.5, 0.5, 1);

	glColor3f(0, 1, 0);
	glVertex3f(-0.5, 0.5, 1);
	glVertex3f(-0.5, -0.5, 1);
	glVertex3f(-0.5, -0.5, 0);

	//bottom face of the cube
	glColor3f(1, 0, 0);
	glVertex3f(-0.5, -0.5, 0);
	glVertex3f(0.5, -0.5, 0);
	glVertex3f(0.5, -0.5, 1);

	glColor3f(0, 1, 0);
	glVertex3f(0.5, -0.5, 1);
	glVertex3f(-0.5, -0.5, 1);
	glVertex3f(-0.5, -0.5, 0);
	*/
	glEnd();

	/*//front face of the cube
	glBegin(GL_TRIANGLES);
	glColor3f(1, 0, 0);
	glVertex3f(0.5, -0.5, 1);
	glVertex3f(0.5, 0.5, 1);
	glVertex3f(-0.5, 0.5, 1);

	glColor3f(0, 1, 0);
	glVertex3f(-0.5, 0.5, 1);
	glVertex3f(-0.5, -0.5, 1);
	glVertex3f(0.5, -0.5, 1);

	glEnd();*/


	/*//blue lines on the cube
	glLineWidth(2.5);
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);

	glVertex3f(0.5, 0.5, 1);
	glVertex3f(0.5, -0.5, 1);

	glVertex3f(0.5, -0.5, 1);
	glVertex3f(0.5, -0.5, 0);

	glVertex3f(0.5, -0.5, 1);
	glVertex3f(-0.5, -0.5, 1);

	glVertex3f(-0.5, -0.5, 1);
	glVertex3f(-0.5, 0.5, 1);

	glVertex3f(-0.5, 0.5, 1);
	glVertex3f(0.5, 0.5, 1);

	glVertex3f(0.5, 0.5, 1);
	glVertex3f(0.5, 0.5, 0);

	glVertex3f(-0.5, 0.5, 1);
	glVertex3f(0.5, -0.5, 1);

	glVertex3f(0.5, 0.5, 0);
	glVertex3f(-0.5, 0.5, 0);

	glVertex3f(-0.5, 0.5, 0);
	glVertex3f(-0.5, 0.5, 1);

	glVertex3f(-0.5, 0.5, 0);
	glVertex3f(0.5, 0.5, 1);

	glVertex3f(0.5, 0.5, 1);
	glVertex3f(0.5, -0.5, 0);

	glEnd();

	//dots on the cube
	glBegin(GL_POINTS);
	glPointSize(100);
	glColor3f(1, 1, 0);
	glVertex3f(0.5, 0.5, 1);
	glVertex3f(0.5, -0.5, 1);
	glVertex3f(0.5, 0.5, 0);
	glVertex3f(0.5, -0.5, 0);
	glVertex3f(-0.5, 0.5, 0);
	glVertex3f(-0.5, 0.5, 1);
	glVertex3f(-0.5, -0.5, 1);*/
	glEnd();

	glFlush();
}

void reshape(int w, int h) {
	// Set the viewport size, based on function input
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size
	glMatrixMode(GL_PROJECTION);
	// first set as identity
	glLoadIdentity();
	// then set perspective projection parameters based
	// on aspect ratio
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 20.0);
	// Set the model view matrix to identity
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	// Set the "look at" point
	gluLookAt(6.0, 5.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key)
	{
		// Use "Esc" key to exit
	case 27:
		exit(0);
		break;
	}
}

int main(int argc, char** argv) {
	// GLUT INITIALIZATION
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("OpenGL Teapot");

	// Additional initalization
	init();

	// Register callback functions
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);

	// Do main loop
	glutMainLoop();

	// Exit
	return 0;
}