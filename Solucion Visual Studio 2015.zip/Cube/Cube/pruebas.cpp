//Estructura del codigo basado en la solucion de un compa�ero que ya tom� el curso un semestre pasado,
//El algoritmo para el rebote es propio
#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <GL/gl.h>
#include "glut.h"  
#include <iostream>
#include <fstream>
#include <assert.h>
#include <string.h>

float X1, Y1, Z1, r1;
float X2, Y2, Z2, r2;

float VX1, VY1, VZ1;
float VX2, VY2, VZ2;

float AX1, AY1, AZ1;
float AX2, AY2, AZ2;

float deltaT;

void SetCollisionColor()
{
	// Define material properties
	GLfloat mat_spec[] = { 30.0, 30.0, 30.0, 1.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 0.4, 0.8, 0.1, 0.0 };

	// Set material properties, as defined above
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf);
}

void SetNormalColor()
{
	// Define material properties
	GLfloat mat_spec[] = { 30.0, 30.0, 30.0, 1.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 0.4, 0.2, 0.0 };

	// Set material properties, as defined above
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf);
}

void init(void)
{
	// Initialize bounding shapes
	X1 = 0.0f;
	Y1 = 0.0f;
	Z1 = 0.0f;
	r1 = 1.0f;

	X2 = 0.0f;
	Y2 = 3.0f;
	Z2 = 0.0f;
	r2 = 1.0f;

	deltaT = 1.0f / 1000.0f;

	// Set light properties...
	GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
	// and create two lights at two positions
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_pos1[] = { -1.0, -1.0, 1.0, 0.0 };

	// Set clear (background) color
	glClearColor(0.0, 0.0, 0.0, 0.0);

	// Set shading model to use
	glShadeModel(GL_SMOOTH);

	// Finish setting up the two lights (position, and component values (specular and diffuse))
	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_pos1);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

	// Enable lighting
	glEnable(GL_LIGHTING);
	// Activate (enable) lights
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	// Enable depth testing (for hidden surface removal)
	glEnable(GL_DEPTH_TEST);
}

void display(void)
{
	// Clear the buffer 
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	VY2 += AY2*deltaT;
	Y2 += VY2*deltaT;

	VY1 += AY1*deltaT;
	Y1 += VY1*deltaT;

	// check for collisions
	float distance = sqrt((X2 - X1)*(X2 - X1) + (Y2 - Y1)*(Y2 - Y1));

	glPushMatrix();
	glTranslatef(X1, Y1, Z1);
	glutWireSphere(r1, 10, 10);
	glutSolidTeapot(r1*0.8);
	glPopMatrix();

	glPushMatrix();
	glTranslatef(X2, Y2, Z2);
	glutWireSphere(r2, 10, 10);
	glutSolidTeapot(r2*0.8);
	glPopMatrix();

	glFlush();

	
	if (distance <= (r1 + r2)) {
		SetCollisionColor();
		AY2 = 1000.0;
		AY1 = -1000.0;
	}
	else if (distance > (r1 + r2)) {
		AY2 = -10.0;
		AY1 = 10.0;
		SetNormalColor();
	}
	else {
		AY2 = 0.0;
		AY1 = 0.0;
	}
}

void reshape(int w, int h)
{
	// Set the viewport size, based on function input
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	// set the projection matrix based on input size
	glMatrixMode(GL_PROJECTION);
	// first set as identity
	glLoadIdentity();
	// then set perspective projection parameters based on aspect ratio
	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 50.0);

	// Set the model view matrix to identity
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	// Set the "look at" point
	gluLookAt(6.0, 5.0, 15.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 27:
		exit(0);
		break;
	}
}

int main(int argc, char** argv)
{
	// GLUT INITIALIZATION
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("OpenGL Teapot");

	// Additional initalization
	init();

	// Register callback functions
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutIdleFunc(display);

	// Do main loop
	glutMainLoop();

	// Exit
	return 0;
}
