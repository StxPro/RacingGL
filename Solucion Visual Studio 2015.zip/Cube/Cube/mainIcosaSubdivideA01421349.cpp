#include <windows.h>
#include <math.h>
#include <GL/gl.h>
//#include <GL/glut.h>
#include <iostream>
#include <ctime> 
#include <array>
#include <vector>
#include "glut.h"
#include <gl/GLU.h>

#define X 0.525731112119133606
#define Z 0.850650808352039932

float dep = 0;

static GLfloat vdata[12][3] = {
	{ -X, 0.0, Z },{ X, 0.0, Z },{ -X, 0.0, -Z },{ X, 0.0, -Z },
	{ 0.0, Z, X },{ 0.0, Z, -X },{ 0.0, -Z, X },{ 0.0, -Z, -X },
	{ Z, X, 0.0 },{ -Z, X, 0.0 },{ Z, -X, 0.0 },{ -Z, -X, 0.0 }
};

static GLuint tindices[20][3] = {
	{ 1,4,0 },{ 4,9,0 },{ 4,5,9 },{ 8,5,4 },{ 1,8,4 },
	{ 1,10,8 },{ 10,3,8 },{ 8,3,5 },{ 3,2,5 },{ 3,7,2 },
	{ 3,10,7 },{ 10,6,7 },{ 6,11,7 },{ 6,0,11 },{ 6,1,0 },
	{ 10,1,6 },{ 11,0,9 },{ 2,11,9 },{ 5,2,9 },{ 11,2,7 }
};

static float rot = 0.0f;
static int divs = 0;

float puntos[8][3];
int caras[12][3];

struct vertex
{
	float x, y, z;
};

struct faces
{
	int a,b,c;
};

vertex points[8];
faces polygons[12];

void DefineShape()
{
	// TO DO - 

	puntos[0][0] = 0.0; // X;
	puntos[0][1] = 0.0; // Y;
	puntos[0][2] = 0.0; // Z;

	points[0].x = 0.0;
	points[0].y = 0.0;
	points[0].z = 0.0;

	// .....

	caras[0][0] = 0;
	caras[0][1] = 1;
	caras[0][2] = 2;

	// .....
}

//Funcion para encontrar un punto de acuerdo a la representacion parametrizada de una linea
//Como entrada recibe t - que es un valor de 0 a 1 y 0.5 representa la mitad de la linea,
//i - representa el eje a devolver 0 para x, 1 para y, y 2 para z
//p1 y p2 son los puntos extremos de la linea
float l(float t, int i, float p1[], float p2[]) {
	//Se obtiene v con la diferencia de los puntos extremos
	float v[3] = { p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2] };
	//Se obtiene vt multiplicando v y t
	float vt[3] = { v[0] * t, v[1] * t, v[2] * t };
	//Se obtienen las coordenadas finales sumando el primer punto extremo de la linea y vt
	float r[3] = { p1[0] + vt[0], p1[1] + vt[1], p1[2] + vt[2] };
	return r[i];
}


void subdivide(float *v1, float *v2, float *v3, long depth) {
	float v12[3], v23[3], v31[3];

	if (depth == 0)
	{
		glBegin(GL_TRIANGLES);
		glColor3f(1, 0, 0);
		glNormal3fv(v1);
		glVertex3fv(v1);
		glColor3f(0, 1, 0);
		glNormal3fv(v2);
		glVertex3fv(v2);
		glColor3f(0, 0, 1);
		glNormal3fv(v3);
		glVertex3fv(v3);
		glEnd();
	}
	else {
		for (int i = 0; i < 3; i++)
		{
			v12[i] = l(0.5, i, v1, v2);
			v23[i] = l(0.5, i, v2, v3);
			v31[i] = l(0.5, i, v3, v1);
		}
		float aux = v12[0] * v12[0] + v12[1] * v12[1]+ v12[2] * v12[2];
		v12[0] /= aux;
		aux = v12[0] * v12[0] + v12[1] * v12[1] + v12[2] * v12[2];
		v12[1] /= aux;
		aux = v12[0] * v12[0] + v12[1] * v12[1] + v12[2] * v12[2];
		v12[2] /= aux;
		aux = v23[0] * v23[0] + v23[1] * v23[1] + v23[2] * v23[2];
		v23[0] /= aux;
		aux = v23[0] * v23[0] + v23[1] * v23[1] + v23[2] * v23[2];
		v23[1] /= aux;
		aux = v23[0] * v23[0] + v23[1] * v23[1] + v23[2] * v23[2];
		v23[2] /= aux;
		aux = v31[0] * v31[0] + v31[1] * v31[1] + v31[2] * v31[2];
		v31[0] /= aux;
		aux = v31[0] * v31[0] + v31[1] * v31[1] + v31[2] * v31[2];
		v31[1] /= aux;
		aux = v31[0] * v31[0] + v31[1] * v31[1] + v31[2] * v31[2];
		v31[2] /= aux;

		subdivide(v12, v23, v31, depth - 1);
		subdivide(v1, v12, v31, depth - 1);
		subdivide(v2, v23, v12, depth - 1);
		subdivide(v3, v31, v23, depth - 1);		
	}	
}

void init(void)
{
	/*// Define material properties
   GLfloat mat_spec[] = { 10.0, 10.0, 10.0, 1.0 };
   GLfloat mat_shiny[] = { 100.0 };
   GLfloat mat_surf[] = { 1.0, 1.0, 0.0, 0.0 };

   // Set light properties...
   GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
   // and create two lights at two positions
   GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
   GLfloat light_pos1[] = { -1.0, -1.0, 1.0, 0.0 };

   // Set clear (background) color
   glClearColor(0.0, 0.0, 0.0, 0.0);

   // Set shading model to use
   glShadeModel (GL_SMOOTH);

   // Set material properties, as defined above
   glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
   glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
   glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);
   //glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_surf);

   // Finish setting up the two lights (position, and component values (specular and diffuse))
   glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
   glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
   glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

   glLightfv(GL_LIGHT1, GL_POSITION, light_pos1);
   glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
   glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

   // Enable lighting
   glEnable(GL_LIGHTING);
   // Activate (enable) lights
   glEnable(GL_LIGHT0);
   glEnable(GL_LIGHT1);

   // Enable depth testing (for hidden surface removal)
   glEnable(GL_DEPTH_TEST);*/
}

void display(void)
{
   // Clear the buffer 
   glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   
   
   // Get model - from library
   //glutSolidTeapot (0.80);

   // Draw mesh model


	//glBegin(GL_TRIANGLES);
   glRotatef(rot, 0.0, 1.0, 0.0);
	for (int i = 0; i < 20; i++)
	{
		/*glNormal3fv(&vdata[tindices[i][0]][0]);
		glVertex3fv(&vdata[tindices[i][0]][0]);
		glNormal3fv(&vdata[tindices[i][1]][0]);
		glVertex3fv(&vdata[tindices[i][1]][0]);
		glNormal3fv(&vdata[tindices[i][2]][0]);
		glVertex3fv(&vdata[tindices[i][2]][0]);*/
		subdivide(&vdata[tindices[i][0]][0], &vdata[tindices[i][1]][0], &vdata[tindices[i][2]][0], dep);
	}
	//glEnd();

   

   glFlush ();
   glutSwapBuffers();
}

void reshape (int w, int h)
{
	// Set the viewport size, based on function input
   glViewport (0, 0, (GLsizei) w, (GLsizei) h);

   // set the projection matrix based on input size
   glMatrixMode (GL_PROJECTION);
   // first set as identity
   glLoadIdentity();
   // then set perspective projection parameters based on aspect ratio
   gluPerspective(20.0, (GLfloat) w/(GLfloat) h, 0.10, 20.0);

   // Set the model view matrix to identity
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();

   // Set the "look at" point
   gluLookAt (6.0, 5.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
   switch (key) {
	   // Use "Esc" key to exit
      case 27:
         exit(0);
         break;
	  case 'q':
		  rot += 0.03;
		  break;
	  case 'w':
		  if(rot>0)
		  rot -= 0.03;
		  break;
	  case 'a':
		  dep += 1;
		  break;
	  case 's':
		  if (dep > 0)
		  dep -= 1;
		  break;
   }
}

int main(int argc, char** argv)
{
	// GLUT INITIALIZATION
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize (400, 400);
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("Isocahedron");

   // Additional initalization
   glEnable(GL_DEPTH_TEST);
   init ();

   // Register callback functions   
   glutKeyboardFunc(keyboard);
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutIdleFunc(display);

   // Do main loop
   glutMainLoop();

   // Exit
   return 0;
}
