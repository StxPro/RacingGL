//
//  main.cpp
//  9objectsLights
//
//  Created by Javier Dalma on 2/27/17.
//  Copyright © 2017 Javier Dalma. All rights reserved.
//

#include <OpenGL/gl.h>
#include <OpenGl/glu.h>
#include <GLUT/glut.h>
#include <cstdlib>

GLfloat spotLight_Direction[] = {0.0, 0.0, -1.0};
float lightMovement = 0.03;

float slices=30;
float stacks=30;

float rotatio=0;

float fogDensiti=0.1;

void init(void)
{
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    GLfloat myPos[] = {3.0, 6.0, 10.0, 2.0};
    glLightfv(GL_LIGHT0, GL_POSITION, myPos);
    
    GLfloat spotLight_Position[] = {0.0, 0.0, 15.0, 1.0};
    GLfloat whiteLight[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat cutOff[] = {5.0};
    GLfloat exponent[] = {2.5};
    glLightfv(GL_LIGHT1, GL_POSITION, spotLight_Position);
    glLightfv(GL_LIGHT1, GL_AMBIENT, whiteLight);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, whiteLight);
    glLightfv(GL_LIGHT1, GL_SPECULAR, whiteLight);
    glLightfv(GL_LIGHT1, GL_SPOT_CUTOFF, cutOff);
    glLightfv(GL_LIGHT1, GL_SPOT_EXPONENT, exponent);
    glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotLight_Direction);
    
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glDisable(GL_LIGHT1);
}


void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glClearColor(0.5,0.5,0.5,1.0);
    
    glShadeModel(GL_SMOOTH);
    //glShadeModel(GL_FLAT);
    
    // Draw objects
    glMatrixMode(GL_MODELVIEW);
    
    //-----------------------Middle Sphere-------------------------------------
    /*GLfloat emerald_Diffuse[] = { 0.07568, 0.61424, 0.07568, 1.0 };
     GLfloat emerald_Specular[] = { 0.633, 0.727811, 0.633, 1.0 };
     GLfloat emerald_Shinny[] = { 10.6 };
     GLfloat emerald_Ambient[] = { 0.0215, 0.1745, 0.0215, 1.0 };
     
     glPushMatrix();
     glMaterialfv(GL_FRONT, GL_SPECULAR, emerald_Specular);
     glMaterialfv(GL_FRONT, GL_SHININESS, emerald_Shinny);
     glMaterialfv(GL_FRONT, GL_DIFFUSE, emerald_Diffuse);
     glMaterialfv(GL_FRONT, GL_AMBIENT, emerald_Ambient);
     glRotated(rotatio, 0.0, 1.0, 0.0);
     glutSolidSphere(2, slices, stacks);
     glPopMatrix();*/
    
    glPushMatrix();
    //-----------------------Right Sphere-------------------------------------
    GLfloat brass_Diffuse[] = { 0.780392, 0.568627, 0.113725, 1.0 };
    GLfloat brass_Specular[] = { 0.992157, 0.941176, 0.807843, 1.0 };
    GLfloat brass_Shinny[] = { 27.8974 };
    GLfloat brass_Ambient[] = { 0.329412, 0.223529, 0.027451, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, brass_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, brass_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, brass_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, brass_Ambient);
    glTranslated(6, 0, 0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Left Sphere-------------------------------------
    GLfloat ruby_Diffuse[] = { 0.61424, 0.04136, 0.04136, 1.0 };
    GLfloat ruby_Specular[] = { 0.727811, 0.626959, 0.626959, 1.0 };
    GLfloat ruby_Shinny[] = { 25.6 };
    GLfloat ruby_Ambient[] = { 0.1745, 0.01175, 0.01175, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, ruby_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, ruby_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, ruby_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, ruby_Ambient);
    glTranslated(-6, 0, 0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Top Sphere-------------------------------------
    GLfloat turquoise_Diffuse[] = { 0.396, 0.74151, 0.69102, 1.0 };
    GLfloat turquoise_Specular[] = { 0.297254, 0.30829, 0.306678, 1.0 };
    GLfloat turquoise_Shinny[] = { 76.8 };
    GLfloat turquoise_Ambient[] = { 0.1, 0.18725, 0.1745, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, turquoise_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, turquoise_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, turquoise_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, turquoise_Ambient);
    glTranslated(0, 6, 0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Bottom Sphere-------------------------------------
    GLfloat copper_Diffuse[] = { 0.7038, 0.27048, 0.0828, 1.0 };
    GLfloat copper_Specular[] = { 0.256777, 0.137622, 0.086014, 1.0 };
    GLfloat copper_Shinny[] = { 12.8 };
    GLfloat copper_Ambient[] = { 0.19125, 0.0735, 0.0225, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, copper_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, copper_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, copper_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, copper_Ambient);
    glTranslated(0, -6, 0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Left Top Corner Sphere-------------------------------------
    GLfloat gold_Diffuse[] = { 0.75164, 0.60648, 0.22648, 1.0 };
    GLfloat gold_Specular[] = { 0.628281, 0.555802, 0.366065, 1.0 };
    GLfloat gold_Shinny[] = { 51.2 };
    GLfloat gold_Ambient[] = { 0.24725, 0.1995, 0.0745, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, gold_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, gold_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, gold_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, gold_Ambient);
    glTranslated(-6, 6, 0.0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Left Bottom Corner Sphere-------------------------------------
    GLfloat pewter_Diffuse[] = { 0.427451, 0.470588, 0.541176, 1.0 };
    GLfloat pewter_Specular[] = { 0.3333, 0.3333, 0.521569, 1.0 };
    GLfloat pewter_Shinny[] = { 9.84615 };
    GLfloat pewter_Ambient[] = { 0.10588, 0.058824, 0.113725, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, pewter_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, pewter_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, pewter_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, pewter_Ambient);
    glTranslated(-6, -6, 0.0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Right Bottom Corner Sphere-------------------------------------
    GLfloat silver_Diffuse[] = { 0.50754, 0.50754, 0.50754, 1.0 };
    GLfloat silver_Specular[] = { 0.508273, 0.508273, 0.508273, 1.0 };
    GLfloat silver_Shinny[] = { 51.2 };
    GLfloat silver_Ambient[] = { 0.19225, 0.19225, 0.19225, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, silver_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, silver_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, silver_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, silver_Ambient);
    glTranslated(6.0, -6, 0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Right Top Corner Sphere-------------------------------------
    GLfloat polishedSilver_Diffuse[] = { 0.2775, 0.2775, 0.2775, 1.0 };
    GLfloat polishedSilver_Specular[] = { 0.773911, 0.773911, 0.773911, 1.0 };
    GLfloat polishedSilver_Shinny[] = { 89.6 };
    GLfloat polishedSilver_Ambient[] = { 0.23125, 0.23125, 0.23125, 1.0 };
    
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_SPECULAR, polishedSilver_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, polishedSilver_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, polishedSilver_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, polishedSilver_Ambient);
    glTranslated(6, 6, 0);
    glRotated(rotatio, 0.0, 1.0, 0.0);
    glutSolidSphere(2, slices, stacks);
    glPopMatrix();
    
    //-----------------------Cube in the Middle-------------------------------------
    
    
    GLfloat emerald_Specular[] = { 0.633, 0.727811, 0.633, 1.0 };
    GLfloat emerald_Shinny[] = { 10.6 };
    GLfloat emerald_Ambient[] = { 0.0215, 0.1745, 0.0215, 1.0 };
    GLfloat emerald_Diffuse[] = { 0.07568, 0.61424, 0.07568, 1.0 };
    
    glRotated(rotatio, 0, 1, 0);
    glPushMatrix();
    
    glMaterialfv(GL_FRONT, GL_SPECULAR, emerald_Specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, emerald_Shinny);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, emerald_Diffuse);
    glMaterialfv(GL_FRONT, GL_AMBIENT, emerald_Ambient);
    
    glBegin(GL_QUADS);
    
    //Front Face
    glNormal3f(0, 0, 1);
    glVertex3f(-2, -2, 2);
    glVertex3f(2, -2, 2);
    glVertex3f(2, 2, 2);
    glVertex3f(-2, 2, 2);
    
    //Left Face
    glNormal3f(-1, 0, 0);
    glVertex3f(-2, 2, 2);
    glVertex3f(-2, 2, -2);
    glVertex3f(-2, -2, -2);
    glVertex3f(-2, -2, 2);
    
    //Bottom face
    glNormal3f(0, -1, 0);
    glVertex3f(-2, -2, 2);
    glVertex3f(2, -2, 2);
    glVertex3f(2, -2, -2);
    glVertex3f(-2, -2, -2);
    
    //Back Face
    glNormal3f(0, 0, -1);
    glVertex3f(-2, -2, -2);
    glVertex3f(-2, 2, -2);
    glVertex3f(2, 2, -2);
    glVertex3f(2, -2, -2);
    
    //Right Face
    glNormal3f(1, 0, 0);
    glVertex3f(2, -2, -2);
    glVertex3f(2, 2, -2);
    glVertex3f(2, 2, 2);
    glVertex3f(2, -2, 2);
    
    //Top Face
    glNormal3f(0, 1, 0);
    glVertex3f(2, 2, 2);
    glVertex3f(2, 2, -2);
    glVertex3f(-2, 2, -2);
    glVertex3f(-2, 2, 2);
    
    glEnd();
    
    glPopMatrix();
    glPopMatrix();
    glFlush();
    glutSwapBuffers();
}

void reshape(int w, int h)
{
    glViewport( 0, 0, (GLsizei) w, (GLsizei) h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-10.0, 10.0, -10.0, 10.0, 0.1, 10.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    GLfloat fogColor[4] = {1.0f,1.0f,1.0f,1.0f};
    
    glEnable(GL_FOG);
    
    glFogi(GL_FOG_MODE, GL_EXP);
    glFogfv(GL_FOG_COLOR, fogColor);
    glFogf (GL_FOG_DENSITY, fogDensiti);
    glFogf (GL_FOG_START, 1.0);
    glFogf (GL_FOG_END, 1.0);
    
    glHint(GL_FOG_HINT, GL_DONT_CARE);
    
    gluLookAt(0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
            // Toggle use of spotlight
        case 'n':
        case 'N':
            glEnable(GL_LIGHT0);
            glDisable(GL_LIGHT1);
            break;
            
        case 'm':
        case 'M':
            glEnable(GL_LIGHT1);
            glDisable(GL_LIGHT0);
            break;
            
        case 27:
            exit(0);
            break;
            
        case 'w':
            slices++;
            break;
            
        case 's':
            slices--;
            break;
            
        case 'r':
            stacks++;
            break;
            
        case 'f':
            stacks--;
            break;
            
        case 'v':
            rotatio+=2;
            break;
            
    }
    glutPostRedisplay();
}

void spotLightMovement(int key, int x, int y) {
    
    switch(key) {
        case GLUT_KEY_UP :
            spotLight_Direction[1] += lightMovement;
            glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotLight_Direction);
            break;
        case GLUT_KEY_DOWN :
            spotLight_Direction[1] -= lightMovement;
            glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotLight_Direction);
            break;
        case GLUT_KEY_LEFT :
            spotLight_Direction[0] -= lightMovement;
            glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotLight_Direction);
            break;
        case GLUT_KEY_RIGHT :
            spotLight_Direction[0] += lightMovement;
            glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spotLight_Direction);
            break;
    }
    glutPostRedisplay();
}


int main (int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(700, 700);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("9 object Lights");
    
    glEnable(GL_DEPTH_TEST);
    init();
    
    glutKeyboardFunc(keyboard);
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutSpecialFunc(spotLightMovement);
    glutIdleFunc(display);
    
    glutMainLoop();
    return 0;
}
