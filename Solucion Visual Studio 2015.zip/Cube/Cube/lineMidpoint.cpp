#include <windows.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glut.h>
//#include "glut.h" 

float puntoMiddle[3] = { 0.5,0.5,0.0 };
float punto1[3];
float punto2[3];
float mover(float,int,float[],float[]);
float tIn = 0.5;

void init(void)
{
	GLfloat mat_spec[] = { 3000.0, 3000.0, 3000.0, 3000.0 };
	GLfloat mat_shiny[] = { 100.0 };
	GLfloat mat_surf[] = { 1.0, 1.0, 0.0, 0.0 };
	GLfloat white_light[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_pos0[] = { 1.0, 1.0, 1.0, 0.0 };
	GLfloat light_pos1[] = { -1.0, -1.0, 1.0, 0.0 };

	glClearColor(0.0, 0.0, 0.0, 0.0);

	glShadeModel(GL_SMOOTH);

	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_spec);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shiny);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_surf);

	glLightfv(GL_LIGHT0, GL_POSITION, light_pos0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT0, GL_SPECULAR, white_light);

	glLightfv(GL_LIGHT1, GL_POSITION, light_pos1);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, white_light);
	glLightfv(GL_LIGHT1, GL_SPECULAR, white_light);

	glEnable(GL_DEPTH_TEST);
	glPointSize(10);
}

// Napoleon Cortes Mata A01421349
void display(void) {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//Dibujar los puntos
	glBegin(GL_POINTS);


	glColor3f(0, 1, 0);
	punto1[0] = 1.0;
	punto1[1] = 0.0;
	punto1[2] = 0.0;
	punto2[0] = 0.0;
	punto2[1] = 1.0;
	punto2[2] = 0.0;
	glVertex3fv(punto1);
	glVertex3fv(punto2);

	glColor3f(1, 0, 0);
	glVertex3fv(puntoMiddle);
	
	glEnd();


	glColor3f(0.0, 0.0, 1.0);

	//Dibujar linea entre los puntos
	glBegin(GL_LINES);
	glColor3f(1, 1, 1);
	glVertex3f(1, 0, 0);
	glVertex3f(0, 1, 0);

	glEnd();

	glFlush();
}

void reshape(int w, int h) {
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

	gluPerspective(20.0, (GLfloat)w / (GLfloat)h, 0.10, 20.0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	gluLookAt(6.0, 5.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void keyboard(unsigned char key, int x, int y) {
	switch (key) {
	case 27:
		exit(0);
		break;
	case 'a':
		if(tIn<0.95)
		tIn += 0.01;
		puntoMiddle[0] = mover(tIn, 0, punto1, punto2);
		puntoMiddle[1] = mover(tIn, 1, punto1, punto2);
		glutPostRedisplay();

		//exit(0);
		break;
	case 'd':
		if (tIn>0.05)
		tIn -= 0.01;
		puntoMiddle[0] = mover(tIn, 0, punto1, punto2);
		puntoMiddle[1] = mover(tIn, 1, punto1, punto2);
		glutPostRedisplay();
		break;
	}
}

float mover(float t, int i, float p1[], float p2[]) {
	float v[3] = { p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2] };
	float vt[3] = { v[0] * t, v[1] * t, v[2] * t};
	float l[3] = { p1[0] + vt[0], p1[1] + vt[1], p1[2] + vt[2] };
	return l[i];
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(400, 400);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("CUBO");

	init();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);

	glutMainLoop();

	return 0;
}



