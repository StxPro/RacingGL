#include <windows.h>
#include <math.h>
#include <GL/gl.h>
//#include <GL/glut.h>
#include <iostream>
#include <ctime> 
#include <array>
#include <vector>
#include "glut.h"

class Planeta {
private:float year, day, yearInc, dayInc;
private:float distance = 0.0;
private:float size = 0.0;
public:Planeta() {

}
public:Planeta(float dist, float siz, float y, float d, float Iy, float Id) {
	year = y;
	day = d;
	yearInc = Iy;
	dayInc = Id;
	distance = dist;
	size = siz;
}
public:void Play() {
	year = (GLfloat)(((GLint)(year * 100.f + yearInc * 100.f)) % 36000) / 100.0f;
	day = (GLfloat)(((GLint)(day * 100.f + dayInc * 100.f)) % 36000) / 100.0f;
}
public:void IncYear() {
	year = (GLfloat)(((GLint)(year * 100.f + yearInc * 100.f)) % 36000) / 100.0f;
}
public:void IncDay() {
	day = (GLfloat)(((GLint)(day * 100.f + dayInc * 100.f)) % 36000) / 100.0f;
}
public:void addIncYear() {
	yearInc += 0.1f;
}
public:void addIncDay() {
	dayInc += 0.1f;
}
public:void Stop() {
	yearInc = 0.0;
	dayInc = 0.0;
}
public:void Moon(float distance, float size, float cicle, int n) {
	for (size_t i = 1; i < n + 1; i++)
	{
		glPushMatrix();
		glRotatef(cicle*(i + 0.0), 0.0, 1.0, 0.0);
		glTranslatef(distance + (i*0.1), 0.0, 0.0);
		glColor3f(1.0, 1.0, 1.0);
		glutSolidSphere(size, 20, 16);
		glPopMatrix();
	}
	glPopMatrix();
}
public:void Planet(bool moons, bool ring)
{
	glPushMatrix();
	glRotatef(year, 0.0, 1.0, 0.0);
	glTranslatef(distance, 0.0, 0.0);
	if (moons) { glPushMatrix(); }

	glRotatef(day, 0.0, 1.0, 0.0);
	glutSolidSphere(size, 20, 16);
	if (ring) {
		glColor3f(139.0 / 255.0, 69.0 / 255.0, 19.0 / 255.0);
		glRotatef(100.0, 1.0, 0.0, 0.0);
		glutWireTorus(0.10, 1.5, 80, 100);
	}
	glPopMatrix();
}
};

class SistemaPlanetario {
private:Planeta planetas[7] = { Planeta(0.0, 0.0, 0.0, 0.0,0.0,0.0) };
public:SistemaPlanetario(float datos[][6]) {
	//planetas[0] = { Planeta(distance, size, y,d,Iy,Id) };
	for (int i = 0; i < 7; i++) {
		planetas[i] = Planeta(datos[i][0], datos[i][1], datos[i][2], datos[i][3], datos[i][4], datos[i][5] );
	}
	}
public:void setPlanet(int planeta, bool moons, bool ring) {
	planetas[planeta].Planet(moons, ring);
}
public:void addMoons(int planeta, float distance, float size, float cicle, int n) {
	planetas[planeta].Moon(distance, size, cicle, n);
}
public:void play() {
	for (auto planet : planetas) {
		planet.Play();
	}
	}
public:void IncYear() {
	for (auto planet : planetas) {
		planet.IncYear();
	}
}
public:void IncDay() {
	for (auto planet : planetas) {
		planet.IncDay();
	}
}
public:void Stop() {
	for (auto planet : planetas) {
		planet.Stop();
	}
}
};

// year, day,yearInc, dayInc
static float rel = 3.5;
static float planets[][4] = {
	{ 0.0f, 0.0f, 0.05f, 0.25f },
	{ 100.0f, 0.0f, 0.05f / 1.5f, 0.25f / 0.8f },
	{ 200.0f, 0.0f, 0.05f / 0.8f, 0.25f / 0.5f },
	{ 300.0f, 0.0f, 0.05f / 1.1f, 0.25f / 0.7f },
	{ 400.0f, 0.0f, 0.05f / 1.9f, 0.25f / 1.6f },
	{ 500.0f, 0.0f, 0.05f / 0.5f, 0.25f / 1.3f },
	{ 600.0f, 0.0f, 0.05f / 0.8f, 0.25f / 0.8f },
	{ 700.0f, 0.0f, 0.05f / 1.2f, 0.25f / 1.0f }
};
static float planetss[][6] = {
	{0.0f,0.0f, 0.0f, 0.0f, 0.05f, 0.25f },
	{ 0.0f,0.0f, 100.0f, 0.0f, 0.05f / 1.5f, 0.25f / 0.8f },
	{ 0.0f,0.0f, 200.0f, 0.0f, 0.05f / 0.8f, 0.25f / 0.5f },
	{ 0.0f,0.0f, 300.0f, 0.0f, 0.05f / 1.1f, 0.25f / 0.7f },
	{ 0.0f,0.0f, 400.0f, 0.0f, 0.05f / 1.9f, 0.25f / 1.6f },
	{ 0.0f,0.0f, 500.0f, 0.0f, 0.05f / 0.5f, 0.25f / 1.3f },
	{ 0.0f,0.0f, 600.0f, 0.0f, 0.05f / 0.8f, 0.25f / 0.8f },
	{ 0.0f,0.0f, 700.0f, 0.0f, 0.05f / 1.2f, 0.25f / 1.0f }
};
static bool doAuto = false;



void Planet(float distance, float size, float year, float day, bool moons, bool ring)
{
	glPushMatrix();
	glRotatef(year, 0.0, 1.0, 0.0);
	glTranslatef(distance, 0.0, 0.0);
	if (moons){ glPushMatrix(); }
		
	glRotatef(day, 0.0, 1.0, 0.0);
	glutSolidSphere(size, 20, 16);
	if (ring) {
		glColor3f(139.0 / 255.0, 69.0 / 255.0, 19.0 / 255.0);
		glRotatef(100.0, 1.0, 0.0, 0.0);
		glutWireTorus(0.10, 1.5, 80, 100);
	}
	glPopMatrix();
}

void Moon(float distance, float size, float cicle, int n) {
	for (size_t i = 1; i < n+1; i++)
	{
		glPushMatrix();
		glRotatef(cicle*(i+0.0), 0.0, 1.0, 0.0);
		glTranslatef(distance+(i*0.1), 0.0, 0.0);
		glColor3f(1.0, 1.0, 1.0);
		glutSolidSphere(size, 20, 16);
		glPopMatrix();
	}	
	glPopMatrix();
}

void init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
	glEnable(GL_DEPTH_TEST);
	
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glColor3f(1.0, 1.0, 0.0);

    // begin solar system
	glPushMatrix();
	glutSolidSphere(1.0, 20, 16);	// draw sun
	glPopMatrix();

	//SistemaPlanetario si = SistemaPlanetario(planetss);
	//si.setPlanet(0, false, false);
	

	glColor3f(1.0, 1.0, 1.0);
    // begin planet 1
	glColor3f(128.0/255.0, 0.0/255.0, 0.0/255.0);
	//distance, size, year, day, moons?
	//si.setPlanet(0, false, false);
	Planet(1.5, 0.55/rel, planets[0][0], planets[0][1], false, false);

	// planet 2
	glColor3f(0.0 / 255.0, 128.0 / 255.0, 128.0 / 255.0);
	//si.setPlanet(1, false, false);
	Planet(2.3, 0.75 / rel, planets[1][0], planets[1][1], false, false);

	// planet 3
	glColor3f(255.0 / 255.0, 69.0 / 255.0, 0.0 / 255.0);
	//si.setPlanet(2, true, false);
	Planet(3.3, 1.0 / rel, planets[2][0], planets[2][1], true, false);
	//distance, size, cicle, n
	Moon(0.5, 0.07, planets[2][0], 1);

	// planet 4
	glColor3f(173.0 / 255.0, 255.0 / 255.0, 47.0 / 255.0);
	//si.setPlanet(3, true, false);
	Planet(4.6, 0.9 / rel, planets[3][0], planets[3][1], true, false);
	//distance, size, cicle, n
	//si.addMoons(3, 0.5, 0.07, planets[3][0], 2);
	Moon(0.5, 0.07, planets[3][0], 2);

	// planet 5
	glColor3f(173.0 / 255.0, 216.0 / 255.0, 230.0 / 255.0);	
	//si.setPlanet(4, true, true);
	Planet(5.9, 2.5 / rel, planets[4][0], planets[4][1], true, true);
	//distance, size, cicle, n
	Moon(0.5, 0.07, planets[4][0], 6);

	// planet 6
	glColor3f(153.0 / 255.0, 50.0 / 255.0, 204.0 / 255.0);
	//si.setPlanet(5, true, false);
	Planet(7.0, 2.0 / rel, planets[5][0], planets[5][1], true, false);
	//distance, size, cicle, n
	Moon(0.5, 0.07, planets[5][0], 3);
	
	// planet 7
	glColor3f(139.0 / 255.0, 69.0 / 255.0, 19.0 / 255.0);
	//si.setPlanet(6, true, false);
	Planet(8.3, 1.2 / rel, planets[6][0], planets[6][1], true, false);
	//distance, size, cicle, n
	Moon(0.5, 0.07, planets[6][0], 2);
	
	// planet 8
	glColor3f(255.0 / 255.0, 127.0 / 255.0, 80.0 / 255.0);
	//si.setPlanet(7, true, false);
	Planet(8.3, 0.8 / rel, planets[7][0], planets[7][1], true, false);
	//distance, size, cicle, n
	Moon(0.5, 0.07, planets[7][0], 2);

	glutSwapBuffers();

	// Code for automatic movement of planet
	if (doAuto) {
		//si.play();
		for (auto planet : planets) {
			planet[0] = (GLfloat)(((GLint)(planet[0] * 100.f + planet[2] * 100.f)) % 36000) / 100.0f;
			planet[1] = (GLfloat)(((GLint)(planet[1] * 100.f + planet[3] * 100.f)) % 36000) / 100.0f;
		}
	}
}

void reshape(int w, int h)
{
	glViewport( 0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 20.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 8.0, 10.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

}


void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
		case 'a':
		case 'A':
			// Toggle automatic movement of planet
			if (doAuto)
				doAuto = false;
			else
				doAuto = true;

		// Manual control of day and year movement
		case 'd':
		case 'D':
			//day			
			for (auto planet : planets)
				//planet[1] = (GLfloat)((GLint)(planet[1] + 1.0f) % 360);
				planet[1] = (GLfloat)(((GLint)(planet[1] * 100.f + planet[3] * 100.f)) % 36000) / 100.0f;

			glutPostRedisplay();
			break;
		case 'y':
		case 'Y':
			//year
			for (auto planet : planets)
				//planet[0] = (GLfloat)((GLint)(planet[0] + 5.0f) % 360);
				planet[0] = (GLfloat)(((GLint)(planet[0] * 100.0 + planet[2] * 100.0)) % 36000) / 100.0;

			glutPostRedisplay();
			break;
		case 0x1B:
		case 'q':
		case 'Q':
			exit(0);
			break;
		default:
			break;
	}
}

void mouse(int btn, int state, int x, int y)
{
	if (state == GLUT_DOWN)
	{
		// Make the year move faster
		if (btn == GLUT_LEFT_BUTTON)
			//yearInc
			//planets[0][2] = planets[0][2] + 0.1f;
		for (auto planet : planets)
			planet[2] = planet[2] + 0.1f;
		// Make the day move faster
		else if (btn == GLUT_RIGHT_BUTTON)
			//dayInc
			//planets[0][3] = planets[0][3] + 0.1f;
			for (auto planet : planets)
				planet[3] = planet[3] + 0.1f;
		// If middle button, then set increment to 0
		else {
			for (auto planet : planets) {
				planet[2] = 0.0f;
				planet[3] = 0.0f;
			}
		}

		glutPostRedisplay();
	}
}

int main (int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Solar System Example");
	init();

	glutMouseFunc(mouse);
	glutKeyboardFunc(keyboard);
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(display);

	glutMainLoop();
	return 0;
}
